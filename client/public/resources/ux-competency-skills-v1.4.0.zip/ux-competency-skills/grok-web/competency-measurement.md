---
name: competency-measurement
description: "Use automatically, without being asked, whenever a task involves measurement and learning: HEART metrics, fake-door or smoke tests, beta or pilot programs, pivot-or-persevere, north-star metric, KPIs, measurement plan, event schema, analytics instrumentation, funnels, cohorts, segmentation, A/B test analysis, product health report, continuous discovery, or whether a release delivered value. Applies competency skills ME-01–ME-14 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs measurement-plan.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Measurement, optimization, and operational learning (ME)

**Goal:** Connect shipped work to outcomes and decide what to do next.

Skills covered: 14 (see the appendix below for evidence, depth, and lead per role). Lead roles in this domain: Product (10), FE Arch (2), UX (2).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in the appendix below and note which role leads each.

## Procedure
1. Pick one outcome metric and 2–4 input metrics the team can move (ME-01).
2. Measurement plan: question → metric → events → properties → identity → consent → owner → QA (ME-02).
3. Event schema: object_action naming, typed properties, versioning, one dictionary (ME-03).
4. Instrument without hurting performance or privacy; verify events in a debug view before release (ME-04).
5. Analyze: funnels for loss (ME-05), cohorts for retention (ME-06), segments for different needs (ME-07).
6. Experiments: check sample ratio, novelty effects, and guardrails before calling a result (ME-08).
7. Pair every quantitative finding with a qualitative explanation (ME-09).
8. Report health: adoption, success, quality, risk, learning — sized for the audience (ME-10).
9. Set the discovery rhythm: weekly customer touchpoint, monthly synthesis, quarterly outcome review (ME-11).
10. Before building, test demand where it's uncertain: fake door, smoke test, concierge, or Wizard of Oz, with a preset threshold (ME-13). For larger bets, run a beta or pilot with exit criteria and a go/no-go (ME-14).
11. After launch, watch behavior (session recordings, heatmaps, in-product surveys) alongside metrics.
12. After release, compare actual vs expected value and decide: scale, persevere, pivot, or stop (ME-12).

## Method selector
| Situation | Use |
|---|---|
| Nobody agrees what success is | ME-01 first, before any event work |
| Drop-off somewhere in a flow | Funnel (ME-05) + session review or usability test (ME-09) |
| A/B result looks too good | ME-08 validity checks |
| Leadership wants a status update | ME-10 one-page health report |
| Defining UX success metrics | HEART: Happiness, Engagement, Adoption, Retention, Task success → signal → metric → target |
| Unsure anyone wants it | Fake-door or smoke test before build (ME-13) |

## Output: `measurement-plan.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Outcome and input metrics
- Questions → events map
- Event dictionary
- Consent and privacy notes
- Dashboards
- Review cadence
- Value-realization check

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**HEART (excerpt):** Happiness — post-setup rating > 4.0 (baseline 2.8); Task success — support contacts per setup −30% within 60 days.
**Events:** `user_setup_started`, `user_setup_step_completed{step}`, `user_setup_completed`.
**Fake door (before build):** "Save and finish later" button shown to 5% of admins; build if click-through > 8%.
**Decision at day 60:** persevere; extend checklist to bulk import.

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Vanity metrics | Tie each metric to a decision |
| Event names drift across teams | Single dictionary with owner |
| Correlation read as cause | Experiment or triangulate |
| No post-launch review | Schedule ME-12 when the work is planned |

## Hand off to
- competency-outcome-review
- competency-product-framing (update bets)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.

---

## Appendix: references/skills.md

### Measurement, optimization, and operational learning (ME) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| ME-01 | North-star and input metric selection | Defines a meaningful outcome metric, controllable input metrics, and a signal–metric–target framework such as HEART. | O | P | L | P | Product |
| ME-02 | Measurement-plan design | Maps events, properties, identity, consent, campaign attribution (UTM), funnel stages, ownership, and QA to a question. | O | P | L | O | Product |
| ME-03 | Event-schema design | Uses consistent event names, properties, versioning, data types, and semantics across product surfaces. | P | P | L | O | FE Arch |
| ME-04 | Instrumentation implementation | Implements analytics events correctly without degrading performance or privacy. | L | L | L | O | FE Arch |
| ME-05 | Funnel analysis | Locates loss, delay, and variation through a multi-step journey. | O | P | L | P | Product |
| ME-06 | Cohort analysis | Compares behavior by acquisition, tenure, role, plan, device, or exposure period. | P | P | — | P | Product |
| ME-07 | Segmentation | Finds materially different needs or outcomes across meaningful populations without overfitting. | P | O | L | P | UX |
| ME-08 | Experiment analysis | Interprets experiment results, validity limits, novelty effects, and decision implications. | O | P | L | P | Product |
| ME-09 | Qual-quant triangulation | Uses behavioral data and human evidence together to explain what happened and why. | O | O | L | P | UX |
| ME-10 | Product-health reporting | Communicates adoption, success, quality, risk, and learning to the right audience. | O | P | L | P | Product |
| ME-11 | Continuous-discovery operating rhythm | Establishes recurring evidence collection, synthesis, decision, and follow-up loops. | O | O | L | P | Product |
| ME-12 | Value-realization review | Assesses whether a released change created expected value and decides to scale, iterate (persevere), pivot, or stop. | O | P | L | P | Product |
| ME-13 | Demand validation | Tests demand before building with fake-door, smoke, concierge, or Wizard-of-Oz tests and preset success thresholds. | O | P | L | P | Product |
| ME-14 | Beta and pilot programs | Recruits pilot users, sets duration and exit criteria, collects structured feedback, and issues a go/no-go recommendation. | O | P | L | P | Product |
