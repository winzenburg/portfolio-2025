---
name: competency-quality-reliability
description: "Use automatically, without being asked, whenever a task involves quality, performance, reliability, privacy, and security: test strategy, unit/integration/e2e tests, accessibility automation, cross-browser testing, Core Web Vitals, performance budgets, offline and resilience, logging and observability, client security, privacy, or incident response. Applies competency skills QL-01–QL-12 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs quality-plan.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Quality engineering, performance, reliability, privacy, and security (QL)

**Goal:** Prove the experience works, stays fast, fails safely, and protects data.

Skills covered: 12 (see the appendix below for evidence, depth, and lead per role). Lead roles in this domain: FE Arch (12).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in the appendix below and note which role leads each.

## Procedure
1. Test plan by risk: unit for logic, integration for seams, end-to-end for the few critical journeys (QL-01–QL-03).
2. Add automated accessibility checks to CI and list what still needs manual testing (QL-04).
3. Pick a browser/device/AT matrix from real usage data (QL-05).
4. Measure Core Web Vitals in the field and the lab; find the bottleneck before optimizing (QL-06).
5. Set budgets (JS size, LCP, INP, CLS) and fail the build when exceeded (QL-07).
6. Design for bad networks: retries with backoff, stale-data indicators, queued writes where needed (QL-08).
7. Instrument errors and traces with user context but no sensitive data (QL-09, QL-11).
8. Client security: escape output, CSP, no secrets or long-lived tokens in client storage, dependency audit (QL-10).
9. Privacy: collect the minimum, honor consent, set retention, scrub telemetry (QL-11).
10. Incidents: triage, communicate impact, mitigate, blameless review, prevention item with owner (QL-12).

## Method selector
| Situation | Use |
|---|---|
| Flaky e2e suite | Cut to critical journeys; stable fixtures; test IDs |
| Site feels slow | Field INP/LCP data first, then trace |
| Field users on poor networks | QL-08 offline and retry design |
| Analytics capturing PII | QL-11 scrub + schema review (ME-03) |

## Output: `quality-plan.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Test strategy by layer
- Browser/AT matrix
- Performance budgets and current values
- Resilience rules
- Observability and privacy rules
- Security checklist
- Incident runbook link

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**Budgets:** LCP < 2.5s, INP < 200ms, CLS < 0.1, setup route JS < 170 KB.
**E2E:** add user happy path; number conflict; session expiry recovery.
**Privacy:** analytics events carry user IDs as hashes, never names or phone numbers.

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| 100% coverage goal | Cover risk, not lines |
| Optimizing without measurement | Trace first |
| Tokens in localStorage | HttpOnly cookies or short-lived memory tokens |
| Incident closed with no follow-up | Prevention item with owner and date |

## Hand off to
- competency-measurement
- competency-leadership-governance (risk management, LG-10)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.

---

## Appendix: references/skills.md

### Quality engineering, performance, reliability, privacy, and security (QL) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| QL-01 | Unit-test design | Tests important logic and behavior with isolated, maintainable cases. | — | L | L | O | FE Arch |
| QL-02 | Integration-test design | Verifies components, state, data, and services working together at meaningful seams. | L | L | L | O | FE Arch |
| QL-03 | End-to-end test design | Automates critical user journeys with stable fixtures, assertions, and failure diagnostics. | P | P | L | O | FE Arch |
| QL-04 | Accessibility-test automation | Integrates automated scanning while recognizing where manual evaluation is required. | L | P | P | O | FE Arch |
| QL-05 | Cross-browser and device testing | Selects and validates browsers, OS, viewport, input, and assistive-technology coverage by risk. | L | P | P | O | FE Arch |
| QL-06 | Performance measurement | Reads and diagnoses field and lab performance data (Core Web Vitals: LCP, INP, CLS), traces, bundle composition, and runtime bottlenecks. | L | L | L | O | FE Arch |
| QL-07 | Performance-budget management | Defines and enforces thresholds for script and style payload, images and fonts, rendering, interaction, and animation cost. | L | L | L | O | FE Arch |
| QL-08 | Resilience and offline design | Handles intermittent connectivity, retries, queues, persistence, stale data, and graceful degradation. | P | P | L | O | FE Arch |
| QL-09 | Observability instrumentation | Produces meaningful logs, errors, traces, user context, and dashboards while protecting privacy. | L | L | L | O | FE Arch |
| QL-10 | Client-side security | Prevents common client exposure through secure rendering, dependency hygiene, token handling, and safe browser APIs. | L | L | L | O | FE Arch |
| QL-11 | Privacy-by-design implementation | Minimizes collection, supports consent and retention requirements, and avoids exposing sensitive data in telemetry. | P | P | L | O | FE Arch |
| QL-12 | Incident participation | Triages defects, communicates impact, mitigates safely, runs blameless review, and prevents recurrence. | P | L | L | O | FE Arch |
