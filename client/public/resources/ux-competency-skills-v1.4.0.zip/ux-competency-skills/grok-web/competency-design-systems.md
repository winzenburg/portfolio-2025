---
name: competency-design-systems
description: "Use automatically, without being asked, whenever a task involves design systems: design system, component library, design tokens, token naming, theming, component anatomy or API, pattern library, documentation, contribution model, visual regression, adoption, design debt, or extracting a design system from an existing product or site. Applies competency skills DS-01–DS-13 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs design-system-plan.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Design systems and design operations (DS)

**Goal:** Run the system as a product: tokens, components, docs, contribution, and adoption, with measurable use.

Skills covered: 13 (see the appendix below for evidence, depth, and lead per role). Lead roles in this domain: UI (9), FE Arch (3), Product (1).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in the appendix below and note which role leads each.

## Procedure
1. Scope: which products, platforms, and teams; goals and explicit non-goals (DS-01). If a product exists but no system does, extract a starter system from it first (DS-13) — owned, client, or licensed sources only.
2. Tokens in three tiers — primitive → semantic → component — with aliasing and theme rules; follow the W3C DTCG format where tooling allows (DS-04).
3. Name tokens by purpose and state, never value (color.text.danger, not red-600) (DS-05).
4. Component anatomy: parts, slots, variants, states, content rules (DS-02).
5. Component API: small, composable props; controlled/uncontrolled patterns; no leaking of internals; accessible by default (DS-03).
6. Decide pattern vs one-off using a reuse threshold (e.g. needed by 3+ teams) (DS-06).
7. Docs per component: when to use, when not, anatomy, accessibility notes, content guidance, code, status (DS-07).
8. Contribution path: propose → review → build → release → own, with a named decision-maker (DS-08).
9. Visual regression baselines and review rules in CI (DS-09).
10. Measure adoption (coverage, detached instances, overrides) and log design debt with size and cost (DS-11, DS-12).

## Method selector
| Situation | Use |
|---|---|
| Inconsistent UI across products | Audit → token layer first → top 10 components |
| System exists, nobody uses it | DS-11 adoption: migration help, champions, metrics |
| Multiple brands or themes | Semantic token layer with theme files |
| Design and code drift | Shared token source + visual regression (DS-09) |

## Output: `design-system-plan.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Scope and non-goals
- Token architecture and naming
- Component inventory with status
- API conventions
- Docs template
- Contribution model
- Adoption metrics
- Debt register

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**Component:** StatusBadge — variants: active, pending, suspended, error, info.
**Rules:** text label always present (never color alone); `role="status"` only when the badge updates live; colors from semantic tokens `color.status.*`.
**Debt logged:** two legacy badge styles in Billing; migrate next quarter.

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Tokens named after values | Rename to purpose; keep primitives private |
| Component with 30 boolean props | Split into composable parts or slots |
| No owner for contributions | Name the decision-maker and the SLA |
| Library treated as the system | Add tokens, docs, governance, and adoption measurement |
| Arbitrary utility values (e.g. one-off Tailwind shadows) | Promote to named tokens |

## Hand off to
- competency-frontend-architecture (component composition, AR-02)
- competency-accessibility
- competency-prototyping-handoff

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.

---

## Appendix: references/skills.md

### Design systems and design operations (DS) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| DS-01 | System scope definition | Defines the products, platforms, users, adoption goals, and non-goals of a system. | P | P | O | O | UI |
| DS-02 | Component anatomy design | Defines stable parts, slots, behaviors, states, and content rules for a component. | P | P | O | O | UI |
| DS-03 | Component API design | Designs composable, discoverable, constrained component props and events without leaking implementation detail. | L | P | P | O | FE Arch |
| DS-04 | Design-token architecture | Creates primitive, semantic, and component tokens with clear aliasing and theming rules. | P | P | O | O | FE Arch |
| DS-05 | Token naming | Uses names that express purpose, scope, and state rather than present implementation values. | P | P | O | O | UI |
| DS-06 | Pattern-library curation | Distinguishes reusable patterns from one-off solutions and maintains a coherent catalog. | P | P | O | O | UI |
| DS-07 | System documentation | Documents usage, anatomy, do/don't guidance, accessibility, content, code, and change status. | P | P | O | O | UI |
| DS-08 | Contribution-model design | Defines proposal, review, implementation, release, and ownership mechanisms for changes. | P | P | O | O | UI |
| DS-09 | Visual-regression governance | Establishes baselines, diff review, exception criteria, and remediation ownership. | L | L | P | O | FE Arch |
| DS-10 | Cross-platform consistency | Maps intent across web, mobile, email, native, and brand contexts without forcing identical controls. | P | P | O | O | UI |
| DS-11 | System adoption enablement | Builds training, migration support, champions, examples, and measurement to drive use. | P | P | O | P | UI |
| DS-12 | Design-debt management | Identifies, sizes, sequences, and funds inconsistency and maintainability reduction. | O | P | O | O | Product |
| DS-13 | Design-system extraction | Derives tokens, type scale, components, and patterns from an existing product or site into a starter system, limited to owned, client, or licensed sources. | L | P | O | O | UI |
