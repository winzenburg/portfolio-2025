---
name: competency-user-research
description: "Use automatically, without being asked, whenever a task involves user research: discovery research, competitive analysis, heuristic evaluation, personas, journey or experience maps, empathy maps, affinity mapping, SUS, unmoderated or tree testing, research ethics, plan research, write an interview guide, run or analyze usability tests, contextual inquiry, task analysis, surveys, diary studies, synthesize findings, or build a research repository. Applies competency skills RE-01–RE-18 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs research-plan.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# User research and evidence synthesis (RE)

**Goal:** Produce evidence that changes a named decision, with honest confidence levels.

Skills covered: 18 (see the appendix below for evidence, depth, and lead per role). Lead roles in this domain: UX (16), Product (2).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in the appendix below and note which role leads each.

## Procedure
1. Name the decision the research will inform and the date it must be made. Write a brief: questions, what we are NOT studying, methods, participants, and 'done when' criteria (RE-01).
2. Start with what's already known: desk research, competitor map by tier (direct, indirect, substitute, potential), and a heuristic review scored 0–4 (RE-13, RE-14).
3. Handle consent, privacy, and incentives; check the screener and guide for bias (RE-18).
4. Pick the method from the selector below; define participant profile, sample size, recruitment criteria (include disability, age, language, device diversity per AX-02), and timeline.
5. Write the guide: past-behavior questions, no leading prompts, tasks phrased as goals not UI instructions (RE-03, RE-09).
6. For workflow products, run task analysis: goal → actions → decisions → inputs → variations → failure points (RE-05).
7. Synthesize with affinity mapping: observation → pattern → insight statement (observation + tension + implication). Tag each with confidence and participant count; triangulate with quantitative data (RE-10). Keep 3–7 insights.
8. Model the user's world where it helps the team act: needs-based personas (2–4 max), experience map, empathy map, mental-model or ecosystem map (RE-15).
9. For evaluative work, report task success, error types, time on task, SUS/SEQ, and severity-rated findings (RE-16, RE-17).
10. Separate stakeholder opinion from user evidence in every readout (RE-02).
11. Communicate in one page: decision, top findings, implications, clips or quotes, open questions (RE-11).
12. File findings where others can find them, with date, method, and link to raw notes (RE-12).

## Method selector
| Situation | Use |
|---|---|
| Don't know the problem space | Generative interviews (RE-03) or contextual inquiry (RE-04) |
| Have a design, need to know if it works | Moderated usability test, 5–8 per segment (RE-09) |
| Need magnitude or prevalence | Survey (RE-06) or behavior analytics (RE-07) |
| Behavior changes over days or weeks | Diary study (RE-08) |
| Complex operational workflow | Contextual inquiry + task analysis (RE-04, RE-05) |
| Need to know where the market is | Desk research + competitor tiers + heuristic benchmark (RE-13, RE-14) |
| Need to validate at scale quickly | Unmoderated test, 20–50 participants; tree test or first-click test, 20–50 (RE-16) |
| Why do people switch products? | JTBD switch interview: timeline + four forces (push, pull, anxiety, habit) |
| Survey for prevalence | Size by margin of error (about 385 completes for ±5% at 95% confidence in a large population) |

## Output: `research-plan.md / research-findings.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Decision to inform
- Method and rationale
- Participants and recruitment
- Guide / tasks
- Findings with confidence
- Implications and recommended decision
- Open questions

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**Decision:** which three setup steps to redesign first (due in 3 weeks).
**Plan:** 6 × 60-min remote interviews with admins (6+ months' tenure) + SUS after each; done when the top 3 friction points have behavioral evidence.
**Insight:** Admins aren't lacking skill; they lack confidence about consequences (6/8 participants; high confidence; matches funnel drop at the step that assigns phone numbers).
**Persona:** "The Reluctant IT Admin" — goal: get people working today; tension: fear of breaking something.

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| "Would you use this?" questions | Ask about the last time they did the task |
| Findings without confidence or counts | Add n and a confidence tag to every finding |
| Coaching participants during tests | Answer questions with questions; note where they got stuck |
| Research that changes nothing | Tie the readout to the decision named at the start |

## Hand off to
- competency-ia-interaction (findings → flows)
- competency-measurement (triangulate with data, ME-09)
- competency-product-framing (update the assumption map)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.

---

## Appendix: references/skills.md

### User research and evidence synthesis (RE) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| RE-01 | Research planning | Selects a method, participant profile, sample, timeline, and decision it will inform. | P | O | L | L | UX |
| RE-02 | Stakeholder interview design | Extracts context, constraints, incentives, and unresolved decisions without treating opinion as evidence. | O | O | L | P | Product |
| RE-03 | Generative interview moderation | Elicits past behavior, context, language, and unmet needs without leading participants. | P | O | L | — | UX |
| RE-04 | Contextual inquiry | Observes work in situ and documents tools, workarounds, interruptions, and environmental constraints. | P | O | L | L | UX |
| RE-05 | Task analysis | Decomposes a user goal into actions, decisions, inputs, variations, and failure points. | P | O | P | P | UX |
| RE-06 | Survey design | Creates unbiased questions, response structures, and sampling logic appropriate to the decision. | P | P | L | L | UX |
| RE-07 | Quantitative behavior analysis | Uses event, funnel, cohort, and segmentation data without confusing correlation and cause. | P | P | L | P | Product |
| RE-08 | Diary-study design | Captures longitudinal behavior, reflections, and changes in context. | L | P | — | — | UX |
| RE-09 | Usability-test moderation | Runs task-based sessions, probes behavior, and avoids coaching participants. | P | O | P | L | UX |
| RE-10 | Research synthesis | Clusters observations with affinity mapping and coding into findings, insight statements (observation, tension, implication), triangulation, and confidence levels. | P | O | L | L | UX |
| RE-11 | Insight communication | Communicates evidence through concise narratives, artifacts, clips, and direct implications. | O | O | P | L | UX |
| RE-12 | Research-repository stewardship | Makes evidence findable, traceable, current, and reusable across teams. | P | P | L | L | UX |
| RE-13 | Secondary and competitive research | Runs desk research and maps competitors by tier (direct, indirect, substitute, potential) into a what-we-know / don't-know summary. | P | O | L | L | UX |
| RE-14 | Heuristic evaluation | Rates an interface against established heuristics (e.g. Nielsen's 10) on a 0–4 severity scale, alone or benchmarked against competitors; includes expert-rating methods such as PURE. | P | O | O | L | UX |
| RE-15 | Experience modeling | Builds needs-based personas (goals, tensions, behaviors — not demographics), experience maps, empathy maps, mental-model diagrams, and ecosystem maps from evidence. | P | O | L | L | UX |
| RE-16 | Evaluative testing at scale | Runs unmoderated tests, tree tests, first-click tests, and desirability studies with samples sized to the question (typically 20–50). | P | O | L | L | UX |
| RE-17 | Usability measurement | Reports task success, error types, time on task, and standardized scores (SUS, SEQ) with severity-rated findings and recommended changes. | P | O | L | L | UX |
| RE-18 | Research ethics and bias control | Handles consent, privacy, and incentives; audits screeners, guides, and synthesis for bias; uses independent coding when stakes are high. | P | O | L | L | UX |
