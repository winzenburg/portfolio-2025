---
name: competency-ideation
description: "Use automatically, without being asked, whenever a task involves ideation and concept development: brainstorming, generating solution ideas, Crazy 8s, SCAMPER, design studio workshops, concept sketches or storyboards, choosing between concepts, concept briefs, concept testing, or running a design sprint. Applies competency skills ID-01–ID-08 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs concepts.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Ideation and concept development (ID)

**Goal:** Go wide on solutions before committing, then converge on tested concepts with a recorded rationale.

Skills covered: 8 (see the appendix below for evidence, depth, and lead per role). Lead roles in this domain: UX (5), Product (3).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in the appendix below and note which role leads each.

## Procedure
1. Start only from a bounded problem: POV, 3–5 HMWs, and constraints (PB-13). If these don't exist, go to competency-product-framing first.
2. Diverge: run a 60–90 minute session that separates generation from judgment; aim for 50–100+ ideas; include a worst-possible-idea round to loosen thinking (ID-01).
3. Push past the obvious with constraints: Crazy 8s (8 ideas in 8 minutes), SCAMPER prompts, analogous inspiration from other industries (ID-02).
4. Make ideas concrete: quick sketches and storyboards showing context, steps, and outcome (ID-03).
5. Run a design studio with engineering, product, and ideally users: sketch → present → critique → iterate (ID-04).
6. Converge: cluster ideas, vote against stated criteria (user value, feasibility, fit with the outcome), pick 3–5 directions, and record why (ID-05).
7. Write a concept brief per direction: problem, how it works, assumptions, risks, test plan (ID-06).
8. Test the concepts with 5–8 target users each against a preset threshold (e.g. preference, comprehension, no critical concerns) (ID-07).
9. When time-boxing everything, run a design sprint: map, sketch, decide, prototype, test (ID-08).

## Method selector
| Situation | Use |
|---|---|
| Team keeps proposing the same idea | Crazy 8s + SCAMPER + analogous inspiration (ID-02) |
| Need cross-functional buy-in | Design studio workshop, 2–3 hours (ID-04) |
| Big bet, one week available | Design sprint (ID-08) |
| Two strong directions, no data | Concept test with 5–8 users per concept (ID-07) |

## Output: `concepts.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Problem and HMWs used
- Idea inventory (count and clusters)
- Selection criteria and votes
- Concept briefs (3–5)
- Concept test plan and results
- Decision and next step

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**Session:** 5 people, 90 min, 47 ideas in 6 clusters.
**Criteria vote:** user confidence, build effort, fit with the completion outcome → top 3: guided checklist (12), inline preview of effects (9), save-and-resume (7).
**Concept brief (checklist):** assumption — admins will follow a visible sequence; risk — feels slow to experts; test — 5 admins, success = completion without help and preference ≥ 70%.

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Critiquing ideas while generating them | Split generation and evaluation into separate rounds |
| Voting on favorites | Vote against written criteria |
| Only one concept reaches testing | Test at least two so preference means something |
| Ideation without a problem statement | Go back to PB-13 first |

## Hand off to
- competency-prototyping-handoff (prototype the chosen concept)
- competency-user-research (usability testing)
- competency-measurement (demand validation, ME-13)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.

---

## Appendix: references/skills.md

### Ideation and concept development (ID) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| ID-01 | Ideation facilitation | Runs divergent sessions (brainstorming, worst-possible-idea) that separate generation from judgment and produce a large, varied idea inventory. | O | O | P | L | UX |
| ID-02 | Structured idea generation | Uses constraint techniques such as Crazy 8s, SCAMPER, and analogous inspiration to push past obvious solutions. | O | O | O | P | UX |
| ID-03 | Concept sketching and storyboarding | Makes ideas concrete with quick sketches and storyboards that show context, steps, and outcome. | P | O | O | L | UX |
| ID-04 | Co-design and design studio | Runs sketch–present–critique–iterate cycles with cross-functional partners or users. | P | O | P | P | UX |
| ID-05 | Concept convergence | Clusters ideas, votes with stated criteria, and selects 3–5 directions with a recorded rationale. | O | P | P | P | Product |
| ID-06 | Concept brief | Documents each direction: problem addressed, how it works, key assumptions, risks, and how it will be tested. | O | P | P | L | Product |
| ID-07 | Concept testing | Tests competing concepts with 5–8 target users each and reports preference, comprehension, and concerns against a preset threshold. | P | O | L | — | UX |
| ID-08 | Design sprint execution | Runs a time-boxed map–sketch–decide–prototype–test sprint and ends with test results and a decision. | O | O | P | P | Product |
