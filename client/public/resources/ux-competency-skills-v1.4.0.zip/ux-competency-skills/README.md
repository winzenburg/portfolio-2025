# UX Competency Skills Pack (v1.4.0)

18 Agent Skills built on a 202-skill taxonomy for Product Design, UX, UI, and Front-End Architecture.
They use the open `SKILL.md` format, so the same folders work in **Cursor** and **Grok Build**, and single-file versions upload to **Grok (web/app) Skills**.

## What's inside
```
skills/                      canonical skills (one folder each: SKILL.md + references/)
grok-web/                    one self-contained .md per skill for Grok web uploads
AURA-CROSSWALK.md            how each Aura skill maps in, and what was left out
DOUBLE-DIAMOND-CROSSWALK.md  how the original Double Diamond playbook maps in
cursor/user-rule.txt         always-on Cursor User Rule for automatic skill use
TAXONOMY.md                  refined taxonomy (all 202 skills, depth + lead)
CHANGELOG.md                 what changed from the 2026-09-10 version
install.sh                   installs to Cursor and Grok Build
```

| Skill | Use it for |
|---|---|
| `competency-router` | Start here. Classifies the request, picks a playbook, plans the chain |
| `competency-audit` | Gap assessment of a product, codebase, team, or person |
| `competency-product-framing` | Product framing, business, and systems thinking (PB) |
| `competency-user-research` | User research and evidence synthesis (RE) |
| `competency-ideation` | Ideation and concept development (ID) |
| `competency-ia-interaction` | Information architecture and interaction design (IA) |
| `competency-content-service-ai` | Content design, service design, and AI interaction design (CX) |
| `competency-ui-visual` | UI design and visual systems (UI) |
| `competency-accessibility` | Accessibility, inclusion, and responsible experience design (AX) |
| `competency-design-systems` | Design systems and design operations (DS) |
| `competency-prototyping-handoff` | Prototyping, specification, and design-to-code collaboration (PR) |
| `competency-frontend-foundations` | Front-end foundations and browser-platform fluency (FE) |
| `competency-frontend-architecture` | Front-end architecture and application systems (AR) |
| `competency-quality-reliability` | Quality engineering, performance, reliability, privacy, and security (QL) |
| `competency-measurement` | Measurement, optimization, and operational learning (ME) |
| `competency-growth-conversion` | Growth, conversion, and marketing surfaces (GM) |
| `competency-leadership-governance` | Collaboration, leadership, governance, and professional judgment (LG) |
| `competency-outcome-review` | Post-release value check and case study |

## Install

### Cursor
Cursor loads skills from `~/.cursor/skills/`, `~/.agents/skills/` (user) and `.cursor/skills/`, `.agents/skills/` (project).
```bash
./install.sh cursor            # copies to ~/.cursor/skills
./install.sh project /path/to/repo   # copies to <repo>/.agents/skills (read by Cursor)
```
Invoke explicitly with `/competency-router`, or just describe the task and the agent picks the skill from its description.

### Cursor: automatic in every project (recommended)
```bash
./install.sh cursor-global
```
This links the skills into `~/.cursor/skills` (available in all projects) and copies a User Rule to your clipboard. Paste it in **Cursor → Customize → Rules → User Rules** and restart Cursor. The skill descriptions tell the agent when to load each one; the User Rule is an always-on index that makes it reach for them without being asked. The rule text is also in `cursor/user-rule.txt`.

### Grok Build (CLI)
Grok Build reads `~/.grok/skills/` (global) and `.grok/skills/` (project).
```bash
./install.sh grok                    # copies to ~/.grok/skills
./install.sh grok-project /path/to/repo   # copies to <repo>/.grok/skills
```

### Both at once, one source of truth
```bash
./install.sh link              # symlinks ~/.cursor/skills/* and ~/.grok/skills/* to this folder
```
Keep this folder somewhere permanent (e.g. `~/skills/ux-competency-skills`) before linking. Edit a skill once here; both tools see the change.

### Grok web / app (Skills)
Grok's Skills importer accepts `.md`, `.skill`, or `.zip`. Upload files from `grok-web/` (each is self-contained with its reference table inlined), or the matching `.skill` files in `grok-web/skill-files/`. Start with `competency-router.md`. In chat-only mode the skills return artifacts inline instead of writing to `docs/competency/`.

## Shared workspace
When a tool can write files, every skill reads and writes `docs/competency/` in the project (brief, audit, plan, chain log, domain artifacts, outcome review). That lets you start a chain in Grok and continue it in Cursor on the same repo.

## Existing installs
Skill names match the 2026-09-10 Cursor set (`competency-*`). `install.sh` moves any existing folder to a sibling `skills-backup-<timestamp>/` (outside the skills folder, so it isn't loaded twice) before replacing it.
