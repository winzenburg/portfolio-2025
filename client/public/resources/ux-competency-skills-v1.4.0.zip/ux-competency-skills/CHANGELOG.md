# Changelog

## 1.4.0 — 2026-09-15
Crosswalk against Ryan's original Double Diamond Playbook (26 skills across Discover, Define, Develop, Deliver, and cross-cutting). See DOUBLE-DIAMOND-CROSSWALK.md.
- New domain 15 **Ideation and concept development** (ID-01–ID-08) and skill `competency-ideation`. The original taxonomy had no divergent solution-generation skill.
- New skills: PB-13–PB-15 (reframing, story mapping, MVP scoping), RE-13–RE-18 (secondary/competitive research, heuristic evaluation, personas and experience maps, testing at scale, usability metrics, research ethics), ME-13–ME-14 (demand validation, beta/pilot), PR-14–PR-15 (UX definition of done, staged release), LG-15–LG-19 (design maturity, UX roadmap, design ROI, DesignOps, working agreements).
- Named methods restored in procedures and method selectors: HMW, POV, 5 Whys, RICE, opportunity scoring, Kano, MoSCoW, OKRs, opportunity solution tree, JTBD four forces, affinity mapping, insight statements, Crazy 8s, SCAMPER, design studio, design sprint, Wizard of Oz, tree/first-click testing, SUS/SEQ, HEART, fake door, Rose/Thorn/Bud, PASS/FAIL/DEFER QA.
- **Double Diamond lens** in the router: every skill ID mapped to Discover / Define / Develop / Deliver / cross-cutting, with explicit exit gates for each phase (the playbook described phases but had no formal gates). New playbook: Full Double Diamond.
- Every domain skill now has an abbreviated worked example using one fictional case (Acme Admin user setup), as the playbook did.
- Resolved: accessibility examples use WCAG 2.2 (the playbook cited 2.1; 2.2 is a superset). Survey sizing expressed as margin of error rather than a fixed "200–400".

### Row changes
- ADDED PB-13 Problem reframing — Double Diamond crosswalk: Problem Framing (POV, HMW, problem brief)
- ADDED PB-14 Story mapping and release slicing — Double Diamond crosswalk: Lean/Agile Developing (story mapping)
- ADDED PB-15 MVP scoping — Double Diamond crosswalk: Lean/Agile Developing (MVP scoping, walking skeleton)
- ADDED RE-13 Secondary and competitive research — Double Diamond crosswalk: Secondary Research
- ADDED RE-14 Heuristic evaluation — Double Diamond crosswalk: Secondary Research (heuristic benchmark), Measurement (PURE)
- ADDED RE-15 Experience modeling — Double Diamond crosswalk: Frameworks & Models
- ADDED RE-16 Evaluative testing at scale — Double Diamond crosswalk: Usability Testing (unmoderated, tree, first-click)
- ADDED RE-17 Usability measurement — Double Diamond crosswalk: Usability Testing outputs
- ADDED RE-18 Research ethics and bias control — Double Diamond crosswalk: Research Planning (ethics & consent), Collaboration & Ethics (bias audit)
- ADDED ID-01 Ideation facilitation — Double Diamond crosswalk: Ideation (brainstorming facilitation)
- ADDED ID-02 Structured idea generation — Double Diamond crosswalk: Ideation (Crazy 8s, SCAMPER, analogous inspiration)
- ADDED ID-03 Concept sketching and storyboarding — Double Diamond crosswalk: Ideation (concept sketching), Frameworks (storyboards)
- ADDED ID-04 Co-design and design studio — Double Diamond crosswalk: Ideation (design studio workshop)
- ADDED ID-05 Concept convergence — Double Diamond crosswalk: Ideation (affinity clustering, dot voting)
- ADDED ID-06 Concept brief — Double Diamond crosswalk: Ideation outputs (concept brief)
- ADDED ID-07 Concept testing — Double Diamond crosswalk: Validation (concept testing)
- ADDED ID-08 Design sprint execution — Double Diamond crosswalk: Lean/Agile Developing (design sprint)
- ADDED ME-13 Demand validation — Double Diamond crosswalk: Validation (fake door, smoke testing)
- ADDED ME-14 Beta and pilot programs — Double Diamond crosswalk: Validation (beta & pilot, go/no-go)
- ADDED PR-14 UX definition of done — Double Diamond crosswalk: Lean/Agile Delivering (DoD contribution)
- ADDED PR-15 Staged release planning — Double Diamond crosswalk: Lean/Agile Delivering (incremental release, rollout gates)
- ADDED LG-15 Design maturity assessment — Double Diamond crosswalk: Strategy (design maturity assessment)
- ADDED LG-16 UX roadmapping — Double Diamond crosswalk: Strategy (UX roadmap)
- ADDED LG-17 Design ROI and business case — Double Diamond crosswalk: Strategy (ROI & business case), Communication (executive storytelling)
- ADDED LG-18 DesignOps — Double Diamond crosswalk: Strategy (DesignOps), Research Planning (research ops)
- ADDED LG-19 Working agreements and review cadence — Double Diamond crosswalk: Collaboration & Ethics (partnership, review cadence)
- PB-09 Product strategy translation: evidence rewritten — Double Diamond crosswalk: OKR alignment
- PB-10 Prioritization: evidence rewritten — Double Diamond crosswalk: named prioritization methods
- PB-08 Systems mapping: evidence rewritten — Double Diamond crosswalk: value stream mapping
- RE-10 Research synthesis: evidence rewritten — Double Diamond crosswalk: synthesis methods
- ME-01 North-star and input metric selection: evidence rewritten — Double Diamond crosswalk: HEART
- ME-12 Value-realization review: evidence rewritten — Double Diamond crosswalk: pivot or persevere
- CX-01 UX writing: evidence rewritten — Double Diamond crosswalk: readability & plain language
- LG-02 Facilitation: evidence rewritten — Double Diamond crosswalk: facilitation techniques and retrospectives

## 1.3.0 — {DATE}
- Skills now load automatically: every description starts with "Use automatically, without being asked, whenever…" and names its triggers.
- Added `cursor/user-rule.txt`, an always-on Cursor User Rule that routes tasks to skills, and `./install.sh cursor-global`.
- Added right-sizing: small tasks apply the checks inline with no files; `docs/competency/` is used only for multi-step work. The router hands single-domain requests straight to the right skill and doesn't ask which skill to use.

## 1.2.0 — {DATE}
Crosswalk against the Aura skills library (aura.build/skills, 167 unique skills). See AURA-CROSSWALK.md.
- New domain 14 **Growth, conversion, and marketing surfaces** (GM-01–GM-10) and skill `competency-growth-conversion`.
- New skills: IA-13, UI-13, UI-14, DS-13, PR-13, FE-13, FE-14, LG-14.
- Refined: UI-12, ME-02, QL-07, LG-03.
- Added **Conflict rules** to TAXONOMY.md and wired them into the UI, DS, PR, FE, GM, and LG skills.
- New playbooks: Marketing site / conversion, UI polish pass, Pressure test.

### Row changes
- ADDED IA-13 Platform-convention fluency — Aura crosswalk: mobile-design-thinking, apple-design
- ADDED UI-13 Visual direction — Aura crosswalk: taste-skill, impeccable-designer, creative-agency-design-protocol, frontend-design, design-dna, image art-direction skills
- ADDED UI-14 Interface polish — Aura crosswalk: details-that-make-interfaces-feel-better, visual-polish-specialist, design-engineering, baseline-ui, typography-cleanup-specialist, beautiful-shadows
- ADDED DS-13 Design-system extraction — Aura crosswalk: extract-design-system, design-dna, ui-consistency-auditor
- ADDED PR-13 Rendered-UI verification — Aura crosswalk: web-design-reviewer, improve-ui, ui-audit-and-quality-review, web-interface-guidelines
- ADDED FE-13 Motion implementation — Aura crosswalk: GSAP, anime.js, animation-systems, ui-animation-guidelines, gsap-performance
- ADDED FE-14 Immersive graphics — Aura crosswalk: three.js, WebGL, cobe, vanta, matter.js, Unicorn Studio skills
- ADDED LG-14 Prompt and skill authoring — Aura crosswalk: skill-creator, prompt-engineer, advanced-ui-prompt-architect, find-skills
- ADDED GM-01 Landing-page architecture — Aura crosswalk: landing-page-high-conversion, saas/editorial page systems
- ADDED GM-02 Conversion copywriting — Aura crosswalk: copywriting
- ADDED GM-03 Pricing-page design — Aura crosswalk: high-conversion-saas-pricing-page-design
- ADDED GM-04 Upgrade and paywall design — Aura crosswalk: paywall-and-upgrade-screen-cro
- ADDED GM-05 Proof design — Aura crosswalk: product-proof-saas, operational-enterprise-ai, company-logos
- ADDED GM-06 Ethical persuasion design — Aura crosswalk: marketing-psychology-mental-models (bounded by LG-11)
- ADDED GM-07 Conversion experiment program — Aura crosswalk: CRO skills
- ADDED GM-08 Search and AI-answer discoverability — Aura crosswalk: geo-generative-engine-optimization-strategies, image-optimization-analysis, features-page-generator
- ADDED GM-09 Brand strategy translation — Aura crosswalk: branding-strategies
- ADDED GM-10 Launch and early-traction design — Aura crosswalk: cold-start-strategies
- UI-12 Motion and transition design: evidence rewritten — Aura crosswalk: added 'where motion earns its place' and springs/interruption (finding-animation-opportunities, apple-design)
- ME-02 Measurement-plan design: evidence rewritten — Aura crosswalk: analytics-tracking adds campaign attribution
- QL-07 Performance-budget management: evidence rewritten — Aura crosswalk: image-optimization and gsap-performance
- LG-03 Design critique: evidence rewritten — Aura crosswalk: grill-me folded in as a critique mode

## 1.1.0 — {DATE}
Refinement of the 2026-09-10 taxonomy and repackaging as an open-standard `SKILL.md` pack for Cursor and Grok.

### Structural fixes
- **Added a Lead column.** In the original, 66 of 156 rows had zero or several "O" owners (IA-07, UI-10, PR-07, PR-12, LG-05 and LG-11 had four). "O" was doing two jobs: *deep specialist* and *accountable owner*. O now means depth only; every skill names exactly one Lead.
- **Depth legend mapped to the 0–4 evidence scale** so audits and role ratings use one language.
- **Senior role summary aligned with the rows.** Accessibility now shows UX as design lead (AX-03/04/08 are UX-led) alongside FE as implementation lead; IA/flows and visual design now show Product as co-owner rather than a second lead, matching the row-level leads.
- **Domain order in the pack follows the delivery sequence** (framing → research → IA → content/AI → UI → accessibility → systems → spec → build → quality → measurement → leadership). Skill IDs are unchanged.

### Row changes
- CX-06 Notification design: UX P → O
- CX-06 Notification design: FE O → P
- RE-02 Stakeholder interview design: UX P → O
- QL-12 Incident participation: evidence rewritten — grammar (verb agreement) and explicit post-incident learning
- QL-06 Performance measurement: evidence rewritten — named the current Core Web Vitals so the skill is testable
- AX-03 Keyboard interaction design: evidence rewritten — anchored to WCAG 2.2 success criteria
- AX-07 Contrast verification: evidence rewritten — anchored to WCAG success criteria
- AX-08 Accessible-form design: evidence rewritten — added WCAG 2.2 form criteria
- AX-11 Touch and mobile accessibility: evidence rewritten — added WCAG 2.2 pointer criteria
- IA-12 Service-blueprint translation: evidence rewritten — disambiguated from CX-11 (IA-12 consumes a blueprint; CX-11 creates one)
- CX-11 Service-design orchestration: evidence rewritten — disambiguated from IA-12
- CX-06 Notification design: evidence rewritten — ownership moved to UX; FE owns delivery infrastructure via AR/QL skills
- LG-11 Ethical decision-making: evidence rewritten — named deceptive patterns explicitly and added escalation
- ADDED CX-13 AI evaluation design — the original priority sequence names 'evaluation' but no skill measured it
- ADDED LG-13 AI-augmented delivery practice — AI agents are now part of the delivery system; the skill is the operating discipline, not the tool

### References added
- web.dev Core Web Vitals (supports QL-06/QL-07) and the WAI ARIA Authoring Practices Guide (supports FE-08/AX-05).

## 1.0.0 — 2026-09-10
Original taxonomy: 156 skills, 13 domains.
