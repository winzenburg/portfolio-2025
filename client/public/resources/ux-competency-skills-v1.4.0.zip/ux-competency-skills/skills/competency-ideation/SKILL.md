---
name: competency-ideation
description: "Use automatically, without being asked, whenever a task involves ideation and concept development: brainstorming, generating solution ideas, Crazy 8s, SCAMPER, design studio workshops, concept sketches or storyboards, choosing between concepts, concept briefs, concept testing, or running a design sprint. Applies competency skills ID-01–ID-08 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs concepts.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Ideation and concept development (ID)

**Goal:** Go wide on solutions before committing, then converge on tested concepts with a recorded rationale.

Skills covered: 8 (see `references/skills.md` for evidence, depth, and lead per role). Lead roles in this domain: UX (5), Product (3).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in `references/skills.md` and note which role leads each.

## Procedure
1. Start only from a bounded problem: POV, 3–5 HMWs, and constraints (PB-13). If these don't exist, go to competency-product-framing first.
2. Diverge: run a 60–90 minute session that separates generation from judgment; aim for 50–100+ ideas; include a worst-possible-idea round to loosen thinking (ID-01).
3. Push past the obvious with constraints: Crazy 8s (8 ideas in 8 minutes), SCAMPER prompts, analogous inspiration from other industries (ID-02).
4. Make ideas concrete: quick sketches and storyboards showing context, steps, and outcome (ID-03).
5. Run a design studio with engineering, product, and ideally users: sketch → present → critique → iterate (ID-04).
6. Converge: cluster ideas, vote against stated criteria (user value, feasibility, fit with the outcome), pick 3–5 directions, and record why (ID-05).
7. Write a concept brief per direction: problem, how it works, assumptions, risks, test plan (ID-06).
8. Test the concepts with 5–8 target users each against a preset threshold (e.g. preference, comprehension, no critical concerns) (ID-07).
9. When time-boxing everything, run a design sprint: map, sketch, decide, prototype, test (ID-08).

## Method selector
| Situation | Use |
|---|---|
| Team keeps proposing the same idea | Crazy 8s + SCAMPER + analogous inspiration (ID-02) |
| Need cross-functional buy-in | Design studio workshop, 2–3 hours (ID-04) |
| Big bet, one week available | Design sprint (ID-08) |
| Two strong directions, no data | Concept test with 5–8 users per concept (ID-07) |

## Output: `concepts.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Problem and HMWs used
- Idea inventory (count and clusters)
- Selection criteria and votes
- Concept briefs (3–5)
- Concept test plan and results
- Decision and next step

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**Session:** 5 people, 90 min, 47 ideas in 6 clusters.
**Criteria vote:** user confidence, build effort, fit with the completion outcome → top 3: guided checklist (12), inline preview of effects (9), save-and-resume (7).
**Concept brief (checklist):** assumption — admins will follow a visible sequence; risk — feels slow to experts; test — 5 admins, success = completion without help and preference ≥ 70%.

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Critiquing ideas while generating them | Split generation and evaluation into separate rounds |
| Voting on favorites | Vote against written criteria |
| Only one concept reaches testing | Test at least two so preference means something |
| Ideation without a problem statement | Go back to PB-13 first |

## Hand off to
- competency-prototyping-handoff (prototype the chosen concept)
- competency-user-research (usability testing)
- competency-measurement (demand validation, ME-13)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
