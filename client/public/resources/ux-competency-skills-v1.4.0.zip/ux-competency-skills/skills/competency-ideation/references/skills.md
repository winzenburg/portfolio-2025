# Ideation and concept development (ID) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| ID-01 | Ideation facilitation | Runs divergent sessions (brainstorming, worst-possible-idea) that separate generation from judgment and produce a large, varied idea inventory. | O | O | P | L | UX |
| ID-02 | Structured idea generation | Uses constraint techniques such as Crazy 8s, SCAMPER, and analogous inspiration to push past obvious solutions. | O | O | O | P | UX |
| ID-03 | Concept sketching and storyboarding | Makes ideas concrete with quick sketches and storyboards that show context, steps, and outcome. | P | O | O | L | UX |
| ID-04 | Co-design and design studio | Runs sketch–present–critique–iterate cycles with cross-functional partners or users. | P | O | P | P | UX |
| ID-05 | Concept convergence | Clusters ideas, votes with stated criteria, and selects 3–5 directions with a recorded rationale. | O | P | P | P | Product |
| ID-06 | Concept brief | Documents each direction: problem addressed, how it works, key assumptions, risks, and how it will be tested. | O | P | P | L | Product |
| ID-07 | Concept testing | Tests competing concepts with 5–8 target users each and reports preference, comprehension, and concerns against a preset threshold. | P | O | L | — | UX |
| ID-08 | Design sprint execution | Runs a time-boxed map–sketch–decide–prototype–test sprint and ends with test results and a decision. | O | O | P | P | Product |
