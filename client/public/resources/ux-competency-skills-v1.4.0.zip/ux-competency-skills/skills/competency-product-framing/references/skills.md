# Product framing, business, and systems thinking (PB) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| PB-01 | Problem framing | Converts an ambiguous request into a bounded problem statement with constraints and desired change. | O | P | L | P | Product |
| PB-02 | Outcome definition | States customer, business, and operational outcomes separately from feature output. | O | P | L | P | Product |
| PB-03 | Assumption mapping | Makes value, usability, feasibility, and viability assumptions explicit and testable. | O | O | L | P | Product |
| PB-04 | Opportunity sizing | Uses qualitative and quantitative evidence to judge materiality of a problem. | O | P | L | L | Product |
| PB-05 | Value-proposition design | Articulates audience, job, differentiated benefit, and proof. | O | P | L | L | Product |
| PB-06 | Jobs-to-be-done analysis | Identifies functional, social, and emotional jobs plus switching triggers. | P | O | L | L | UX |
| PB-07 | Domain-model comprehension | Understands the entities, rules, vocabulary, and exceptions of a customer domain. | O | O | P | O | Product |
| PB-08 | Systems mapping | Maps actors, dependencies, feedback loops, value streams, and operational handoffs around the experience. | O | P | L | O | Product |
| PB-09 | Product strategy translation | Converts a strategy into experience principles, outcome-based OKRs, bets, and decision criteria. | O | P | L | P | Product |
| PB-10 | Prioritization | Applies a transparent method (RICE, opportunity scoring, Kano, MoSCoW, impact/effort) to sequence work under capacity and risk constraints. | O | L | L | P | Product |
| PB-11 | Experiment design | Specifies a falsifiable hypothesis, population, treatment, measure, and decision threshold. | O | P | L | P | Product |
| PB-12 | Trade-off articulation | Explains customer, business, design, technical, legal, and operational consequences of a choice. | O | P | P | O | Product |
| PB-13 | Problem reframing | Writes point-of-view statements ([user] needs [need] because [insight]), generates 10–20 How-Might-We questions, and narrows them to 3–5 with a stated 'not solving' boundary. | O | O | P | L | Product |
| PB-14 | Story mapping and release slicing | Maps the user journey as activities and steps, places stories beneath, and cuts thin end-to-end release slices. | O | P | L | P | Product |
| PB-15 | MVP scoping | Defines the smallest release that tests the core hypothesis: in scope, deferred, success metrics, timebox, and team. | O | P | L | P | Product |
