# User research and evidence synthesis (RE) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| RE-01 | Research planning | Selects a method, participant profile, sample, timeline, and decision it will inform. | P | O | L | L | UX |
| RE-02 | Stakeholder interview design | Extracts context, constraints, incentives, and unresolved decisions without treating opinion as evidence. | O | O | L | P | Product |
| RE-03 | Generative interview moderation | Elicits past behavior, context, language, and unmet needs without leading participants. | P | O | L | — | UX |
| RE-04 | Contextual inquiry | Observes work in situ and documents tools, workarounds, interruptions, and environmental constraints. | P | O | L | L | UX |
| RE-05 | Task analysis | Decomposes a user goal into actions, decisions, inputs, variations, and failure points. | P | O | P | P | UX |
| RE-06 | Survey design | Creates unbiased questions, response structures, and sampling logic appropriate to the decision. | P | P | L | L | UX |
| RE-07 | Quantitative behavior analysis | Uses event, funnel, cohort, and segmentation data without confusing correlation and cause. | P | P | L | P | Product |
| RE-08 | Diary-study design | Captures longitudinal behavior, reflections, and changes in context. | L | P | — | — | UX |
| RE-09 | Usability-test moderation | Runs task-based sessions, probes behavior, and avoids coaching participants. | P | O | P | L | UX |
| RE-10 | Research synthesis | Clusters observations with affinity mapping and coding into findings, insight statements (observation, tension, implication), triangulation, and confidence levels. | P | O | L | L | UX |
| RE-11 | Insight communication | Communicates evidence through concise narratives, artifacts, clips, and direct implications. | O | O | P | L | UX |
| RE-12 | Research-repository stewardship | Makes evidence findable, traceable, current, and reusable across teams. | P | P | L | L | UX |
| RE-13 | Secondary and competitive research | Runs desk research and maps competitors by tier (direct, indirect, substitute, potential) into a what-we-know / don't-know summary. | P | O | L | L | UX |
| RE-14 | Heuristic evaluation | Rates an interface against established heuristics (e.g. Nielsen's 10) on a 0–4 severity scale, alone or benchmarked against competitors; includes expert-rating methods such as PURE. | P | O | O | L | UX |
| RE-15 | Experience modeling | Builds needs-based personas (goals, tensions, behaviors — not demographics), experience maps, empathy maps, mental-model diagrams, and ecosystem maps from evidence. | P | O | L | L | UX |
| RE-16 | Evaluative testing at scale | Runs unmoderated tests, tree tests, first-click tests, and desirability studies with samples sized to the question (typically 20–50). | P | O | L | L | UX |
| RE-17 | Usability measurement | Reports task success, error types, time on task, and standardized scores (SUS, SEQ) with severity-rated findings and recommended changes. | P | O | L | L | UX |
| RE-18 | Research ethics and bias control | Handles consent, privacy, and incentives; audits screeners, guides, and synthesis for bias; uses independent coding when stakes are high. | P | O | L | L | UX |
