---
name: competency-frontend-architecture
description: "Use automatically, without being asked, whenever a task involves front-end architecture: application structure, module boundaries, component composition, state management, data fetching and caching, API contracts, SSR/SSG/streaming choice, auth states, feature flags, error boundaries, ADRs, or front-end technical roadmap. Applies competency skills AR-01–AR-12 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs architecture.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Front-end architecture and application systems (AR)

**Goal:** Keep the client-side system understandable, reliable, and cheap to change as the product grows.

Skills covered: 12 (see `references/skills.md` for evidence, depth, and lead per role). Lead roles in this domain: FE Arch (12).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in `references/skills.md` and note which role leads each.

## Procedure
1. Map the current structure: pages, features, domains, shared UI, utilities, platform. Mark boundary violations (AR-01, AR-10).
2. Decide local vs shared components; don't extract until a second real use exists (AR-02).
3. State inventory: server, client, URL, form, cache, transient UI. Each piece of state has one owner (AR-03).
4. Data fetching: cache keys, invalidation, loading/error/empty, retry, pagination, optimistic updates (AR-04).
5. Agree API contracts with backend: payload shape, error semantics, versioning (AR-05).
6. Choose rendering per route: client, server, static, streaming, or hybrid, with the reason (AR-06).
7. Auth: session expiry, re-auth, role-based UI, access-denied states (AR-07).
8. Feature flags with owner and removal date (AR-08). Error boundaries at route and widget level with retry (AR-09).
9. Write an ADR for each consequential choice: context, options, decision, consequences, revisit trigger (AR-11).
10. Roll the findings into a sequenced technical roadmap tied to product risk (AR-12).

## Method selector
| Situation | Use |
|---|---|
| Same data in three stores | State ownership table (AR-03), then consolidate |
| Slow first load on content pages | Server or static rendering for those routes (AR-06) |
| One bug blanks the whole app | Error boundaries per route and widget (AR-09) |
| Big framework decision | ADR with at least two real alternatives (AR-11) |

## Output: `architecture.md + adr/NNNN-title.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Current structure and boundary issues
- State ownership table
- Data-fetching rules
- Rendering strategy by route
- Flags and error boundaries
- ADR index
- Technical roadmap

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**State ownership:** draft user in form state, synced to server as a draft; current step in the URL (`?step=phone`); number availability in the fetch cache with a 30-second stale time.
**ADR-0012:** server-render the setup shell for fast first load; client-side steps after that.

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Global store for everything | Server state in a fetching cache; URL state in the URL |
| Premature shared component | Wait for the second use |
| Flags never removed | Owner + expiry on every flag |
| Architecture = framework choice | Document boundaries, ownership, and change cost instead |

## Hand off to
- competency-quality-reliability
- competency-measurement (instrumentation, ME-04)
- competency-leadership-governance (technical critique, LG-04)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
