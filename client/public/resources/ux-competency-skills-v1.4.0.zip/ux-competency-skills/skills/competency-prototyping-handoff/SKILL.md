---
name: competency-prototyping-handoff
description: "Use automatically, without being asked, whenever a task involves prototyping, specification, and handoff: wireframes, Wizard of Oz, definition of done, staged rollout, prototype, pick prototype fidelity, write interaction specs, responsive specs, edge cases, acceptance criteria, design handoff, design QA, checking built UI in the browser with screenshots, or design-engineering pairing. Applies competency skills PR-01–PR-15 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs spec.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Prototyping, specification, and design-to-code collaboration (PR)

**Goal:** Test at the right fidelity, then hand off intent and rules, not just pictures.

Skills covered: 15 (see `references/skills.md` for evidence, depth, and lead per role). Lead roles in this domain: UX (5), UI (4), Product (4), FE Arch (2).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in `references/skills.md` and note which role leads each.

## Procedure
1. Name the risk being tested; match prototype fidelity to the fidelity of the question — paper, clickable, Wizard of Oz, coded, live-data, or service prototype (PR-03).
2. Low-fi for structure and language; high-fi for visual, state, and interaction decisions (PR-01, PR-02).
3. Use realistic data, long strings, latency, and errors so results aren't falsely positive (PR-04).
4. Interaction spec: trigger → state change → feedback → exit, with timing and input behavior (PR-05).
5. Responsive spec: container or breakpoint rules, reflow, priority changes, density (PR-06).
6. Edge cases: empty, loading, error, permission, long content, unusual data, offline/degraded (PR-07).
7. Acceptance criteria in Given/When/Then, including accessibility and state coverage (PR-08).
8. Handoff: intent, token and component references, state rules, assets, open questions (PR-09).
9. Pair with engineering on ambiguous parts; record decisions (PR-10).
10. Design QA against the spec; log deviations by severity (PR-11).
11. Verify in a real browser: each breakpoint, light/dark, key states; capture screenshots, fix, re-check, and send the change for human review (PR-13).
12. Update the spec when implementation teaches something (PR-12). Mark QA items PASS / FAIL / DEFER and log deferred items as design debt.
13. Put UX criteria into the team's definition of done (PR-14) and plan staged rollout with a success gate and rollback per phase (PR-15).

## Method selector
| Situation | Use |
|---|---|
| Unsure if the flow makes sense | Low-fi clickable, 5 users |
| Unsure if it's technically feasible | Coded spike with real data (PR-04) |
| Engineers keep asking the same questions | Edge-case table + interaction spec |
| Shipped UI drifts from design | Design QA checklist per story (PR-11) |

## Output: `spec.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Intent and scope
- Prototype link and what it tested
- Interaction rules
- Responsive rules
- Edge-case table
- Acceptance criteria
- Design QA log
- Decision log

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**Fidelity decision:** mid-fi clickable, 6 screens, 5 admins — the question is flow and comprehension, not visual polish.
**Edge cases:** 0 numbers available; 60-character names; admin session expires mid-flow.
**Acceptance:** Given an admin on the Review step, when a required field is missing, then the step is flagged and focus moves to the first error.
**QA:** 18 PASS, 2 FAIL (launch blockers), 3 DEFER (logged as debt).

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Screenshots as the spec | Add rules, states, and intent |
| Lorem ipsum in tests | Use real content and worst-case lengths |
| Acceptance criteria restate the mockup | Write observable behavior and conditions |
| Spec never updated after build | PR-12: update or mark superseded |

## Hand off to
- competency-frontend-foundations / competency-frontend-architecture (build)
- competency-quality-reliability (tests from acceptance criteria)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
