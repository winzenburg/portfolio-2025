# Double Diamond lens

The pack is organized by competency; this file maps every skill ID to the Double Diamond phase where it is usually applied, and adds an exit gate for each phase. Teams move back to earlier phases whenever evidence demands.

## Discover (diverge on the problem)

| Skill | IDs |
|---|---|
| `competency-user-research` | RE-01, RE-02, RE-03, RE-04, RE-05, RE-06, RE-07, RE-08, RE-13, RE-14, RE-18 |
| `competency-product-framing` | PB-04, PB-06, PB-07, PB-08 |
| `competency-measurement` | ME-05, ME-06, ME-07, ME-11 |
| `competency-accessibility` | AX-02 |

**Exit gate**
- [ ] Every research question in the brief is answered or explicitly parked
- [ ] At least 5 distinct perspectives heard for each key segment
- [ ] Top friction points backed by behavioral evidence, not opinion
- [ ] A what-we-know / what-we-don't summary exists

## Define (converge on the problem)

| Skill | IDs |
|---|---|
| `competency-user-research` | RE-10, RE-11, RE-12, RE-15 |
| `competency-product-framing` | PB-01, PB-02, PB-03, PB-05, PB-09, PB-10, PB-11, PB-13 |
| `competency-measurement` | ME-01, ME-02 |
| `competency-content-service-ai` | CX-03, CX-11 |
| `competency-ia-interaction` | IA-01, IA-02, IA-12 |

**Exit gate**
- [ ] POV statement, 3–5 HMWs, and a written 'not solving' list
- [ ] Opportunities prioritized with a visible method
- [ ] Outcome metrics and testable hypotheses agreed
- [ ] Decision-maker has signed off (decision log entry)

## Develop (diverge on solutions)

| Skill | IDs |
|---|---|
| `competency-ideation` | ID-01, ID-02, ID-03, ID-04, ID-05, ID-06, ID-08 |
| `competency-ui-visual` | UI-01, UI-02, UI-03, UI-04, UI-05, UI-06, UI-07, UI-08, UI-09, UI-10, UI-11, UI-12, UI-13, UI-14 |
| `competency-design-systems` | DS-01, DS-02, DS-03, DS-04, DS-05, DS-06, DS-07, DS-08, DS-09, DS-10, DS-11, DS-12, DS-13 |
| `competency-frontend-foundations` | FE-01, FE-02, FE-03, FE-04, FE-05, FE-06, FE-07, FE-08, FE-09, FE-10, FE-11, FE-12, FE-13, FE-14 |
| `competency-frontend-architecture` | AR-01, AR-02, AR-03, AR-04, AR-05, AR-06, AR-07, AR-08, AR-09, AR-10, AR-11, AR-12 |
| `competency-ia-interaction` | IA-03, IA-04, IA-05, IA-06, IA-07, IA-08, IA-09, IA-10, IA-11, IA-13 |
| `competency-content-service-ai` | CX-01, CX-02, CX-04, CX-05, CX-06, CX-07, CX-08, CX-09, CX-10, CX-12, CX-13 |
| `competency-prototyping-handoff` | PR-01, PR-02, PR-03, PR-04, PR-05, PR-06, PR-07, PR-08, PR-09, PR-10 |
| `competency-product-framing` | PB-14, PB-15 |
| `competency-growth-conversion` | GM-01, GM-02, GM-03, GM-04, GM-05, GM-06, GM-09 |
| `competency-accessibility` | AX-01, AX-03, AX-04, AX-05, AX-06, AX-08, AX-09, AX-10, AX-11 |

**Exit gate**
- [ ] At least two concepts explored; chosen concept met its test threshold
- [ ] Prototype at the right fidelity passed usability testing with no critical issues
- [ ] Spec covers states, edge cases, responsive rules, accessibility annotations, and acceptance criteria
- [ ] MVP scope and release slices agreed

## Deliver (converge on the solution)

| Skill | IDs |
|---|---|
| `competency-ideation` | ID-07 |
| `competency-user-research` | RE-09, RE-16, RE-17 |
| `competency-accessibility` | AX-07, AX-12 |
| `competency-prototyping-handoff` | PR-11, PR-12, PR-13, PR-14, PR-15 |
| `competency-quality-reliability` | QL-01, QL-02, QL-03, QL-04, QL-05, QL-06, QL-07, QL-08, QL-09, QL-10, QL-11, QL-12 |
| `competency-measurement` | ME-03, ME-04, ME-08, ME-09, ME-10, ME-12, ME-13, ME-14 |
| `competency-growth-conversion` | GM-07, GM-08, GM-10 |

**Exit gate**
- [ ] Definition of done met: accessibility criticals fixed, design QA passed, analytics tagged, copy final
- [ ] Each rollout phase passed its success gate; rollback ready
- [ ] Metrics dashboard live with baselines
- [ ] Value review scheduled (outcome-review)

## Cross-cutting (always on)

| Skill | IDs |
|---|---|
| `competency-leadership-governance` | LG-01, LG-02, LG-03, LG-04, LG-05, LG-06, LG-07, LG-08, LG-09, LG-10, LG-11, LG-12, LG-13, LG-14, LG-15, LG-16, LG-17, LG-18, LG-19 |
| `competency-product-framing` | PB-12 |

**Exit gate**
- [ ] Decisions, owners, and dates recorded
- [ ] Risks and ethics checked for this phase
