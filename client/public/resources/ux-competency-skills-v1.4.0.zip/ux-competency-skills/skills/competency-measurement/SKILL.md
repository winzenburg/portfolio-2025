---
name: competency-measurement
description: "Use automatically, without being asked, whenever a task involves measurement and learning: HEART metrics, fake-door or smoke tests, beta or pilot programs, pivot-or-persevere, north-star metric, KPIs, measurement plan, event schema, analytics instrumentation, funnels, cohorts, segmentation, A/B test analysis, product health report, continuous discovery, or whether a release delivered value. Applies competency skills ME-01–ME-14 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs measurement-plan.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Measurement, optimization, and operational learning (ME)

**Goal:** Connect shipped work to outcomes and decide what to do next.

Skills covered: 14 (see `references/skills.md` for evidence, depth, and lead per role). Lead roles in this domain: Product (10), FE Arch (2), UX (2).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in `references/skills.md` and note which role leads each.

## Procedure
1. Pick one outcome metric and 2–4 input metrics the team can move (ME-01).
2. Measurement plan: question → metric → events → properties → identity → consent → owner → QA (ME-02).
3. Event schema: object_action naming, typed properties, versioning, one dictionary (ME-03).
4. Instrument without hurting performance or privacy; verify events in a debug view before release (ME-04).
5. Analyze: funnels for loss (ME-05), cohorts for retention (ME-06), segments for different needs (ME-07).
6. Experiments: check sample ratio, novelty effects, and guardrails before calling a result (ME-08).
7. Pair every quantitative finding with a qualitative explanation (ME-09).
8. Report health: adoption, success, quality, risk, learning — sized for the audience (ME-10).
9. Set the discovery rhythm: weekly customer touchpoint, monthly synthesis, quarterly outcome review (ME-11).
10. Before building, test demand where it's uncertain: fake door, smoke test, concierge, or Wizard of Oz, with a preset threshold (ME-13). For larger bets, run a beta or pilot with exit criteria and a go/no-go (ME-14).
11. After launch, watch behavior (session recordings, heatmaps, in-product surveys) alongside metrics.
12. After release, compare actual vs expected value and decide: scale, persevere, pivot, or stop (ME-12).

## Method selector
| Situation | Use |
|---|---|
| Nobody agrees what success is | ME-01 first, before any event work |
| Drop-off somewhere in a flow | Funnel (ME-05) + session review or usability test (ME-09) |
| A/B result looks too good | ME-08 validity checks |
| Leadership wants a status update | ME-10 one-page health report |
| Defining UX success metrics | HEART: Happiness, Engagement, Adoption, Retention, Task success → signal → metric → target |
| Unsure anyone wants it | Fake-door or smoke test before build (ME-13) |

## Output: `measurement-plan.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Outcome and input metrics
- Questions → events map
- Event dictionary
- Consent and privacy notes
- Dashboards
- Review cadence
- Value-realization check

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**HEART (excerpt):** Happiness — post-setup rating > 4.0 (baseline 2.8); Task success — support contacts per setup −30% within 60 days.
**Events:** `user_setup_started`, `user_setup_step_completed{step}`, `user_setup_completed`.
**Fake door (before build):** "Save and finish later" button shown to 5% of admins; build if click-through > 8%.
**Decision at day 60:** persevere; extend checklist to bulk import.

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Vanity metrics | Tie each metric to a decision |
| Event names drift across teams | Single dictionary with owner |
| Correlation read as cause | Experiment or triangulate |
| No post-launch review | Schedule ME-12 when the work is planned |

## Hand off to
- competency-outcome-review
- competency-product-framing (update bets)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
