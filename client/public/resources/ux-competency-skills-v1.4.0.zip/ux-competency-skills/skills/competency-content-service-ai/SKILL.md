---
name: competency-content-service-ai
description: "Use automatically, without being asked, whenever a task involves content, service, and AI interaction: UX writing, microcopy, error messages, empty states, notifications, onboarding, terminology, localization, service blueprints, conversational UI, AI confidence and provenance, human-in-the-loop, or AI evals. Applies competency skills CX-01–CX-13 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs content-and-ai-spec.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Content design, service design, and AI interaction design (CX)

**Goal:** Make words, services, and AI behavior trustworthy and actionable.

Skills covered: 13 (see `references/skills.md` for evidence, depth, and lead per role). Lead roles in this domain: UX (7), Product (5), FE Arch (1).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in `references/skills.md` and note which role leads each.

## Procedure
1. Build or check the glossary: one term per concept, in user language, matched to the domain model (CX-03).
2. Write labels and instructions for the task, front-loaded, short, and plain; check reading level (about grade 8 for general audiences) and show before/after rewrites (CX-01, CX-02).
3. Error messages: what happened, why if it helps, what to do now, where to get help (CX-04).
4. Empty states: orientation, value, next action — or an honest reason nothing can be done yet (CX-05).
5. Notifications: trigger, audience, channel, timing, priority, frequency cap, user preference (CX-06).
6. Onboarding: progressive setup tied to the activation event; no mandatory tours (CX-07).
7. Blueprint the service across front stage and backstage when more than one channel or team is involved (CX-11).
8. For AI features: show confidence and sources, state limits, suggest verification (CX-09); assign automate / review / escalate / override to named actors (CX-10); define the eval set and release threshold before launch (CX-13); design turn-taking, repair, and exit for conversational flows (CX-08).
9. Check for localization: text expansion (+30–40%), RTL, locale formats, no text in images (CX-12).

## Method selector
| Situation | Use |
|---|---|
| AI output can be wrong in costly ways | CX-10 human review + CX-09 provenance + CX-13 eval gate |
| Users ignore notifications | CX-06 audit: fatigue, relevance, channel |
| Many teams touch the journey | CX-11 service blueprint first |
| Terminology fights | CX-03 glossary with owner and decision log |

## Output: `content-and-ai-spec.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Glossary
- Copy deck (labels, errors, empty states)
- Notification matrix
- Onboarding path
- Service blueprint
- AI behavior spec: confidence, provenance, HITL roles, evals, fallbacks

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**Before:** "Error 4032: DID assignment failed."
**After:** "That phone number is already in use. Pick another number or release it from its current user."
**Glossary:** DID → Phone number; SKU → Plan.
**AI note:** suggested role shows its source ("based on 12 users in Sales") and a confidence label; admin must confirm.

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| "Something went wrong" errors | Name the problem and the recovery action |
| AI answer shown with no source or confidence | Add provenance and a verification prompt |
| Automation with no override | Every automated action needs a human reversal path |
| Evals written after launch | No release without an agreed threshold |

## Hand off to
- competency-accessibility (cognitive accessibility)
- competency-leadership-governance (AI governance, LG-12)
- competency-quality-reliability (fallback and incident handling)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
