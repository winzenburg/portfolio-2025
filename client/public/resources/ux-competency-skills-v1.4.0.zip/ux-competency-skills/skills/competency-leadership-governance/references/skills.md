# Collaboration, leadership, governance, and professional judgment (LG) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| LG-01 | Stakeholder alignment | Identifies decision-makers, incentives, conflict, and needed commitments; creates shared clarity. | O | O | P | O | Product |
| LG-02 | Facilitation | Runs inclusive working sessions and retrospectives (e.g. Rose/Thorn/Bud) that produce decisions, artifacts, owners, and next steps. | O | O | P | O | UX |
| LG-03 | Design critique | Gives and receives evidence-based critique focused on intent, risk, and user outcome rather than taste; can run a structured pressure-test of a plan. | O | O | O | P | UX |
| LG-04 | Technical critique | Evaluates architectural proposals for boundaries, risk, simplicity, cost, and evolvability. | L | L | L | O | FE Arch |
| LG-05 | Narrative communication | Explains a recommendation through context, evidence, decision, trade-off, and next action. | O | O | O | O | Product |
| LG-06 | Executive communication | Compresses complexity into decisions, consequence, confidence, and required support. | O | P | P | O | Product |
| LG-07 | Influence without authority | Builds trust, frames choices, and advances decisions across functions without positional control. | O | O | P | O | Product |
| LG-08 | Conflict resolution | Surfaces disagreement constructively, separates facts from preferences, and closes on a documented decision. | O | O | P | O | Product |
| LG-09 | Estimation and capacity reasoning | Frames scope, uncertainty, sequencing, dependencies, and trade-offs realistically. | P | L | L | O | FE Arch |
| LG-10 | Risk management | Identifies product, usability, accessibility, security, dependency, and delivery risks early. | O | P | P | O | Product |
| LG-11 | Ethical decision-making | Recognizes and blocks deceptive patterns, discrimination, privacy harm, unsafe automation, and conflicts of interest; escalates when needed. | O | O | O | O | Product |
| LG-12 | AI-governance collaboration | Establishes review, auditability, data boundaries, human accountability, and monitoring for AI-enabled experiences. | O | P | L | O | Product |
| LG-13 | AI-augmented delivery practice | Uses AI agents for research, design, and code with explicit specs, verification steps, provenance, and human review before anything ships. | O | P | P | O | Product |
| LG-14 | Prompt and skill authoring | Writes reusable prompts, specs, and agent skills with clear triggers, inputs, steps, quality bars, and evals; retires stale ones. | O | P | P | O | Product |
| LG-15 | Design maturity assessment | Scores a team or organization on a design-maturity model and names the capabilities needed to reach the next level. | P | O | P | P | UX |
| LG-16 | UX roadmapping | Builds a 12–18 month experience roadmap in outcome-based horizons tied to product strategy. | O | O | P | P | UX |
| LG-17 | Design ROI and business case | Quantifies the cost of the problem and the expected return of design work with stated assumptions and ranges. | O | P | L | L | Product |
| LG-18 | DesignOps | Sets up tools, workflows, research operations, reviews, and staffing models so design work scales. | P | O | O | P | UX |
| LG-19 | Working agreements and review cadence | Establishes cross-functional working agreements, design review rhythm, and critique norms. | O | O | P | O | Product |
