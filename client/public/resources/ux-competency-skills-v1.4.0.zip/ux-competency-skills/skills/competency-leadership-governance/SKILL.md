---
name: competency-leadership-governance
description: "Use automatically, without being asked, whenever a task involves leadership and governance: design maturity, UX roadmap, design ROI or business case, DesignOps, retrospectives, stakeholder alignment, workshop facilitation, design or technical critique, executive readout, influencing without authority, resolving conflict, estimation, risk register, ethics review, AI governance, AI-augmented team practice, writing prompts or agent skills, or pressure-testing a plan. Applies competency skills LG-01–LG-19 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs decision-log.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Collaboration, leadership, governance, and professional judgment (LG)

**Goal:** Get the right decision made, recorded, and owned — across functions and with AI in the loop.

Skills covered: 19 (see `references/skills.md` for evidence, depth, and lead per role). Lead roles in this domain: Product (12), UX (5), FE Arch (2).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in `references/skills.md` and note which role leads each.

## Procedure
1. Stakeholder map: decision-maker, influencers, incentives, what each needs to commit to (LG-01). Agree working agreements and a design review cadence (LG-19).
2. Workshops and retros: goal, timed agenda, pre-read, decision method (dot vote, MoSCoW), critique format (e.g. Rose/Thorn/Bud), output, owners (LG-02).
3. Critique: state intent and constraints first; feedback tied to user outcome and risk, not taste (LG-03). Technical critique: boundaries, risk, simplicity, cost, evolvability (LG-04).
4. Narrative: context → evidence → recommendation → trade-off → next action (LG-05).
5. Executive version: situation → what we learned → recommendation → expected outcome → next step, one page (LG-06). Quantify cost of the problem and expected return with ranges (LG-17).
6. Design strategy: assess maturity and name the next level's capabilities (LG-15); build an outcome-based 12–18 month UX roadmap (LG-16); set up DesignOps (LG-18).
7. Conflict: separate facts from preferences, agree criteria, decide, write it down (LG-07, LG-08).
8. Estimate with ranges and named uncertainties; show dependencies (LG-09).
9. Risk register: product, usability, accessibility, security, dependency, delivery — likelihood, impact, owner, mitigation (LG-10).
10. Ethics check: deceptive patterns, discrimination, privacy harm, unsafe automation, conflicts of interest (LG-11).
11. AI governance: data boundaries, review points, audit trail, human accountability, monitoring (LG-12). AI-augmented delivery: spec before prompt, verify generated output, record provenance, human sign-off (LG-13). Author reusable prompts and skills with triggers, steps, quality bar, and evals (LG-14).
12. Pressure-test mode (LG-03): question the plan one assumption at a time until each has evidence, a test, or an accepted risk.

## Method selector
| Situation | Use |
|---|---|
| Stuck between two camps | Agree decision criteria first (LG-08) |
| Need exec approval | LG-06 one-pager with a clear ask |
| Team shipping AI-generated code/design | LG-13 verification and review gates |
| AI feature touches sensitive data | LG-12 governance review before build |
| Leadership asks 'why invest in design?' | LG-17 ROI model + LG-15 maturity score |
| Design team can't scale | LG-18 DesignOps + LG-19 working agreements |

## Output: `decision-log.md / exec-readout.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Stakeholder map
- Decision record (context, options, decision, owner, date)
- Risk register
- Ethics and AI-governance checks
- Executive one-pager

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**Exec one-pager:** Situation — setup confusion drives support cost. Learned — three steps cause most contacts. Recommend — 6-week guided-setup release. Expected — contacts −30%, completion 9% → 25%. Ask — one engineer for 6 weeks.
**Maturity:** team at "reactive"; next-level capabilities: research cadence, design QA in DoD, shared metrics.

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Meeting ends without owners | Close every session with decision, owner, date |
| Exec deck is a design walkthrough | Lead with the decision and consequence |
| Taste-based critique | Ask: which user outcome or risk does this affect? |
| AI output merged unreviewed | Human sign-off and provenance note required |

## Hand off to
- competency-outcome-review
- competency-audit (re-baseline)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
