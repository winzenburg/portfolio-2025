---
name: competency-accessibility
description: "Use automatically, without being asked, whenever a task involves accessibility and inclusion: accessibility, a11y, WCAG, keyboard navigation, screen readers, ARIA, contrast, accessible forms, captions, cognitive load, touch targets, or accessibility audits and remediation. Applies competency skills AX-01–AX-12 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs accessibility-report.md."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Accessibility, inclusion, and responsible experience design (AX)

**Goal:** Meet WCAG 2.2 AA as a design and architecture requirement, not a final QA pass.

Skills covered: 12 (see `references/skills.md` for evidence, depth, and lead per role). Lead roles in this domain: UX (6), FE Arch (3), UI (3).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in `references/skills.md` and note which role leads each.

## Procedure
1. Set the target (normally WCAG 2.2 AA plus any contract or legal policy) and turn it into acceptance criteria for this work (AX-01, PR-08).
2. Keyboard: define focus order, visible and unobscured focus, escape behavior, no traps (AX-03).
3. Screen reader: name, role, state, and relationship for every control; live-region announcements for async changes; reading order (AX-04).
4. Use native HTML elements first; ARIA only when no native element fits (AX-05, FE-08).
5. Never rely on color alone; verify contrast for text (4.5:1, 3:1 large) and non-text/focus (3:1) (AX-06, AX-07).
6. Forms: persistent visible labels, programmatic error association, no redundant entry, accessible authentication (AX-08).
7. Pointer and mobile: 24×24 CSS px minimum targets, single-pointer alternative to dragging, reflow at 320 CSS px, respects reduced motion (AX-11).
8. Media: captions, transcripts, user control of playback (AX-09).
9. Cognitive: plain language, predictable behavior, no unnecessary time limits, consistent help location (AX-10).
10. Test: automated scan + keyboard-only pass + screen readers (VoiceOver or NVDA on desktop; VoiceOver or TalkBack on mobile) + zoom 200%/400%. Log each issue with WCAG criterion, severity, and fix (AX-12, QL-04).

## Method selector
| Situation | Use |
|---|---|
| Design stage | Annotate focus order, headings, landmarks, names in the spec |
| Code review | Semantic HTML check, then ARIA check |
| Existing product with debt | Audit critical journeys first, fix by user impact |
| Procurement / VPAT request | Map findings to WCAG SC with conformance levels |

## Output: `accessibility-report.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Target standard
- Acceptance criteria
- Issues table: ID, WCAG SC, severity, location, fix, owner
- Test coverage (tools, AT, browsers)
- Residual risk

## Example (abbreviated)
_Fictional case used across the pack: Acme Admin, a B2B SaaS portal where IT admins add and provision users. All numbers are illustrative._

**Target:** WCAG 2.2 AA.
**Findings (excerpt):** 1.3.1 step headings not marked up (Critical); 2.4.3 focus jumps to footer after save (Major); 1.4.3 helper text 3.2:1 (Major).
**Fix plan:** heading levels in the stepper component; move focus to the step heading on navigation; raise helper-text contrast via token change.

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Automated scan treated as full audit | Automated tools catch only a portion of WCAG failures; add keyboard and screen-reader testing |
| div/span buttons with ARIA | Use <button>; it brings keyboard and semantics for free |
| Placeholder used as label | Visible persistent label |
| Accessibility deferred to 'phase 2' | Put criteria in the story's definition of done |

## Hand off to
- competency-quality-reliability (automate checks, QL-04)
- competency-design-systems (fix at the component level)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
