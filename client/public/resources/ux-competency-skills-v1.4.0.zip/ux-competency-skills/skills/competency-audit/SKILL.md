---
name: competency-audit
description: "Assess a product, codebase, team, or person against the 202-skill UX/Product/UI/Front-End competency taxonomy. Use for UX audits, design maturity or capability assessments, front-end health checks, portfolio or career gap analysis, hiring rubrics, or scoping a consulting engagement. Produces a scored gap register with owner role, fix-with skill, and effort."
metadata:
  pack: ux-competency-skills
  version: "1.4.0"
---

# Competency audit

Two modes: **work mode** (audit a product or codebase) and **people mode** (audit a person or team). Same scale, different evidence.

## Steps
1. Confirm scope: mode, which domains (default: all 15 at a glance, then deep-dive the 3–4 that matter), and the decision the audit supports.
2. Gather evidence. Work mode: screens, flows, repo, analytics, support tickets, research. People mode: artifacts, decisions they enabled, constraints, results, what changed afterward. A polished mockup or a commit alone is not evidence of senior capability.
3. Score each in-scope skill 0–4 using `references/taxonomy.md`. Every score needs one line of evidence; mark "no evidence" rather than guessing.
4. For work mode, compare against the expected depth for the team's roles; for people mode, compare against the target role column and spine.
5. Build the gap register (table below). Rank by risk × effort.
6. Summarize: top 3 risks, top 3 strengths, recommended playbook(s) from `competency-router`.

## Scale
0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Target depth: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

## Output: `audit.md`
- Scope and evidence sources
- Domain heatmap (15 rows, score 0–4, one-line rationale)
- Gap register:

| ID | Skill | Score | Target | Evidence | Risk (H/M/L) | Lead role | Fix with | Effort (S/M/L) |
|---|---|---|---|---|---|---|---|---|

- Top risks and strengths
- Recommended playbook and first three steps

## Using the gap register to scope work
Each High or Medium row becomes a work package: the "Fix with" skill is the method, the Lead role is the owner, Effort sizes it. Group rows by playbook to form proposal or SOW phases.

## Failure modes
| Symptom | Fix |
|---|---|
| Scores with no evidence | Mark "no evidence" and list what would be needed |
| All 158 skills scored superficially | Heatmap all domains, deep-score only the ones that matter |
| Scoring people against every O | Score against their role column and chosen spine |
| UI review turns into taste debate | Use UI-14 and PR-13 checks; cite the rule or token each finding breaks |
| Findings with no owner | Every gap gets a Lead role |

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
