---
name: competency-prototyping-handoff
description: "Use automatically, without being asked, whenever a task involves prototyping, specification, and handoff: prototype, pick prototype fidelity, write interaction specs, responsive specs, edge cases, acceptance criteria, design handoff, design QA, checking built UI in the browser with screenshots, or design-engineering pairing. Applies competency skills PR-01–PR-13 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs spec.md."
metadata:
  pack: ux-competency-skills
  version: "1.3.0"
---

# Prototyping, specification, and design-to-code collaboration (PR)

**Goal:** Test at the right fidelity, then hand off intent and rules, not just pictures.

Skills covered: 13 (see the appendix below for evidence, depth, and lead per role). Lead roles in this domain: UX (4), UI (4), Product (3), FE Arch (2).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in the appendix below and note which role leads each.

## Procedure
1. Name the risk being tested; pick the prototype that tests it cheapest — paper, clickable, coded, data-backed, or service (PR-03).
2. Low-fi for structure and language; high-fi for visual, state, and interaction decisions (PR-01, PR-02).
3. Use realistic data, long strings, latency, and errors so results aren't falsely positive (PR-04).
4. Interaction spec: trigger → state change → feedback → exit, with timing and input behavior (PR-05).
5. Responsive spec: container or breakpoint rules, reflow, priority changes, density (PR-06).
6. Edge cases: empty, loading, error, permission, long content, unusual data, offline/degraded (PR-07).
7. Acceptance criteria in Given/When/Then, including accessibility and state coverage (PR-08).
8. Handoff: intent, token and component references, state rules, assets, open questions (PR-09).
9. Pair with engineering on ambiguous parts; record decisions (PR-10).
10. Design QA against the spec; log deviations by severity (PR-11).
11. Verify in a real browser: each breakpoint, light/dark, key states; capture screenshots, fix, re-check, and send the change for human review (PR-13).
12. Update the spec when implementation teaches something (PR-12).

## Method selector
| Situation | Use |
|---|---|
| Unsure if the flow makes sense | Low-fi clickable, 5 users |
| Unsure if it's technically feasible | Coded spike with real data (PR-04) |
| Engineers keep asking the same questions | Edge-case table + interaction spec |
| Shipped UI drifts from design | Design QA checklist per story (PR-11) |

## Output: `spec.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Intent and scope
- Prototype link and what it tested
- Interaction rules
- Responsive rules
- Edge-case table
- Acceptance criteria
- Design QA log
- Decision log

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Screenshots as the spec | Add rules, states, and intent |
| Lorem ipsum in tests | Use real content and worst-case lengths |
| Acceptance criteria restate the mockup | Write observable behavior and conditions |
| Spec never updated after build | PR-12: update or mark superseded |

## Hand off to
- competency-frontend-foundations / competency-frontend-architecture (build)
- competency-quality-reliability (tests from acceptance criteria)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.

---

## Appendix: references/skills.md

### Prototyping, specification, and design-to-code collaboration (PR) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| PR-01 | Low-fidelity prototyping | Uses rough artifacts to test structure, flow, and language before visual polish. | O | O | P | L | UX |
| PR-02 | High-fidelity prototyping | Models visual states, interaction, feedback, and responsive intent at decision-ready fidelity. | O | O | O | P | UI |
| PR-03 | Prototype selection | Chooses paper, clickable, coded, data-backed, or service prototype according to the risk being tested. | O | O | P | P | UX |
| PR-04 | Prototype realism calibration | Includes enough realistic data, latency, content, and errors to avoid false-positive learning. | P | O | P | O | UX |
| PR-05 | Interaction specification | Documents triggers, state transitions, rules, animation, input behavior, and exceptions. | P | O | O | O | UX |
| PR-06 | Responsive specification | Specifies breakpoints or container behavior, reflow, priority changes, and density adjustments. | P | P | O | O | UI |
| PR-07 | Edge-case specification | Defines empty, loading, error, permission, long-content, unusual-data, and degraded-mode behavior. | O | O | O | O | Product |
| PR-08 | Acceptance-criteria writing | Expresses user-visible requirements and observable conditions for completion. | O | P | P | O | Product |
| PR-09 | Design handoff | Supplies intent, system references, state rules, assets, and examples without pretending screenshots are specifications. | P | P | O | O | UI |
| PR-10 | Engineer-design pairing | Resolves ambiguity live, compares alternatives, and protects outcome while adapting implementation. | O | O | P | O | FE Arch |
| PR-11 | Design QA | Detects and prioritizes deviations across function, layout, content, states, accessibility, and responsiveness. | P | P | O | O | UI |
| PR-12 | Implementation feedback incorporation | Updates design artifacts after discovery of real platform constraints or new learning. | O | O | O | O | Product |
| PR-13 | Rendered-UI verification | Checks the built UI in a real browser across viewports, themes, and states with screenshots; fixes, re-verifies, and submits changes for review. | L | P | O | O | FE Arch |
