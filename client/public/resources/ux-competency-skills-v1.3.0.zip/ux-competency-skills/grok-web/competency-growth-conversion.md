---
name: competency-growth-conversion
description: "Use automatically, without being asked, whenever a task involves growth, conversion, and marketing surfaces: landing pages, homepage or features pages, conversion copy, pricing pages, paywalls and upgrade prompts, social proof and demos, CRO tests, SEO or AI-search (GEO) visibility, brand strategy for the site, or getting first users. Applies competency skills GM-01–GM-10 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs page-brief.md."
metadata:
  pack: ux-competency-skills
  version: "1.3.0"
---

# Growth, conversion, and marketing surfaces (GM)

**Goal:** Turn product value into pages and moments that convert, without deceptive patterns.

Skills covered: 10 (see the appendix below for evidence, depth, and lead per role). Lead roles in this domain: Product (9), FE Arch (1).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in the appendix below and note which role leads each.

## Procedure
1. Name the audience, the single promise, and the one primary action for the surface (GM-01).
2. Collect proof before writing: real UI, workflow demo, verifiable numbers, attributable quotes, logos with permission (GM-05).
3. Write the page in customer language: headline, value proposition, how it works, proof, objections, CTA (GM-02). Task microcopy stays CX-01.
4. Pricing: plans by who they're for, comparison table, billing toggle, FAQs, clear enterprise path (GM-03).
5. Upgrade moments: trigger at realized value or a real limit, preview the paid value, keep the free path visible (GM-04).
6. Persuasion check: every behavioral technique must be true and reversible; remove fake scarcity, confirmshaming, pre-checked add-ons, hidden costs (GM-06, LG-11).
7. Discoverability: semantic headings, metadata, structured data, server-rendered content, optimized images, answer-ready sections (GM-08).
8. Brand: apply positioning and voice rules from the brand owner; visual direction per UI-13 (GM-09).
9. Set up the test program: hypothesis, metric, guardrail, sample, decision rule; track attribution per ME-02 (GM-07).
10. For zero-to-one products, plan first-user channels and the activation path, then review weekly (GM-10).

## Method selector
| Situation | Use |
|---|---|
| New landing page | GM-01 outline → GM-05 proof → GM-02 copy → UI-13 direction |
| Visitors don't convert | Funnel data (ME-05) + 5-second test, then GM-07 backlog |
| Free users don't upgrade | GM-04 upgrade moments tied to activation data |
| Not showing up in AI answers | GM-08: structure, citations, crawlable content |

## Output: `page-brief.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Audience, promise, primary action
- Proof inventory
- Page outline and copy
- Pricing / upgrade logic
- Persuasion and ethics check
- SEO/GEO checklist
- Experiment backlog

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Page tries to speak to everyone | One audience per page; route others elsewhere |
| Claims with no proof | Replace with real UI, numbers, or remove |
| Countdown timers and fake stock | Delete; they breach GM-06 and erode trust |
| Hero animation hurts LCP | Static first paint; defer motion (FE-13, QL-07) |

## Hand off to
- competency-ui-visual (visual direction and polish)
- competency-measurement (attribution and experiment analysis)
- competency-accessibility

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.

---

## Appendix: references/skills.md

### Growth, conversion, and marketing surfaces (GM) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| GM-01 | Landing-page architecture | Structures a page around one audience, one promise, proof, objections, and one primary action. | O | P | O | P | Product |
| GM-02 | Conversion copywriting | Writes headlines, value propositions, CTAs, and objection handling in customer language; distinct from task-focused UX writing (CX-01). | O | P | L | — | Product |
| GM-03 | Pricing-page design | Presents plans, comparison, billing options, FAQs, and the enterprise path so buyers can choose without a sales call. | O | P | O | L | Product |
| GM-04 | Upgrade and paywall design | Places upgrade moments at points of realized value, previews paid value, and never blocks core work or hides the free path. | O | O | P | P | Product |
| GM-05 | Proof design | Uses real product UI, workflow demos, verifiable metrics, logos, and attributable testimonials as evidence. | O | P | O | P | Product |
| GM-06 | Ethical persuasion design | Applies behavioral principles (clarity, anchoring, social proof, defaults) and rejects deceptive patterns such as fake scarcity, confirmshaming, and hidden costs. | O | O | P | L | Product |
| GM-07 | Conversion experiment program | Maintains a hypothesis backlog, prioritizes tests, and runs experiments on acquisition and upgrade surfaces; analysis per ME-08. | O | P | L | P | Product |
| GM-08 | Search and AI-answer discoverability | Ships semantic structure, metadata, structured data, crawlable rendering, fast media, and citable content for search engines and AI answers (SEO/GEO). | P | P | L | O | FE Arch |
| GM-09 | Brand strategy translation | Turns positioning, voice, and identity rules into site and product guidance, in partnership with brand owners; application in product stays UI-11. | O | P | O | L | Product |
| GM-10 | Launch and early-traction design | Designs first-user channels, activation paths, and feedback loops for zero-to-one products. | O | P | L | L | Product |
