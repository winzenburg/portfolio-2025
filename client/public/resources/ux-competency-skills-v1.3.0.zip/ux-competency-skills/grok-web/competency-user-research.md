---
name: competency-user-research
description: "Use automatically, without being asked, whenever a task involves user research: plan research, write an interview guide, run or analyze usability tests, contextual inquiry, task analysis, surveys, diary studies, synthesize findings, or build a research repository. Applies competency skills RE-01–RE-12 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs research-plan.md."
metadata:
  pack: ux-competency-skills
  version: "1.3.0"
---

# User research and evidence synthesis (RE)

**Goal:** Produce evidence that changes a named decision, with honest confidence levels.

Skills covered: 12 (see the appendix below for evidence, depth, and lead per role). Lead roles in this domain: UX (10), Product (2).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in the appendix below and note which role leads each.

## Procedure
1. Name the decision the research will inform and the date it must be made. No decision, no study (RE-01).
2. Pick the method from the selector below; define participant profile, sample size, recruitment criteria (include disability, age, language, device diversity per AX-02), and timeline.
3. Write the guide: past-behavior questions, no leading prompts, tasks phrased as goals not UI instructions (RE-03, RE-09).
4. For workflow products, run task analysis: goal → actions → decisions → inputs → variations → failure points (RE-05).
5. Synthesize: observation → pattern → finding → implication. Tag each finding with confidence (high/medium/low) and count of participants (RE-10).
6. Separate stakeholder opinion from user evidence in every readout (RE-02).
7. Communicate in one page: decision, top findings, implications, clips or quotes, open questions (RE-11).
8. File findings where others can find them, with date, method, and link to raw notes (RE-12).

## Method selector
| Situation | Use |
|---|---|
| Don't know the problem space | Generative interviews (RE-03) or contextual inquiry (RE-04) |
| Have a design, need to know if it works | Moderated usability test, 5–8 per segment (RE-09) |
| Need magnitude or prevalence | Survey (RE-06) or behavior analytics (RE-07) |
| Behavior changes over days or weeks | Diary study (RE-08) |
| Complex operational workflow | Contextual inquiry + task analysis (RE-04, RE-05) |

## Output: `research-plan.md / research-findings.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Decision to inform
- Method and rationale
- Participants and recruitment
- Guide / tasks
- Findings with confidence
- Implications and recommended decision
- Open questions

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| "Would you use this?" questions | Ask about the last time they did the task |
| Findings without confidence or counts | Add n and a confidence tag to every finding |
| Coaching participants during tests | Answer questions with questions; note where they got stuck |
| Research that changes nothing | Tie the readout to the decision named at the start |

## Hand off to
- competency-ia-interaction (findings → flows)
- competency-measurement (triangulate with data, ME-09)
- competency-product-framing (update the assumption map)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.

---

## Appendix: references/skills.md

### User research and evidence synthesis (RE) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| RE-01 | Research planning | Selects a method, participant profile, sample, timeline, and decision it will inform. | P | O | L | L | UX |
| RE-02 | Stakeholder interview design | Extracts context, constraints, incentives, and unresolved decisions without treating opinion as evidence. | O | O | L | P | Product |
| RE-03 | Generative interview moderation | Elicits past behavior, context, language, and unmet needs without leading participants. | P | O | L | — | UX |
| RE-04 | Contextual inquiry | Observes work in situ and documents tools, workarounds, interruptions, and environmental constraints. | P | O | L | L | UX |
| RE-05 | Task analysis | Decomposes a user goal into actions, decisions, inputs, variations, and failure points. | P | O | P | P | UX |
| RE-06 | Survey design | Creates unbiased questions, response structures, and sampling logic appropriate to the decision. | P | P | L | L | UX |
| RE-07 | Quantitative behavior analysis | Uses event, funnel, cohort, and segmentation data without confusing correlation and cause. | P | P | L | P | Product |
| RE-08 | Diary-study design | Captures longitudinal behavior, reflections, and changes in context. | L | P | — | — | UX |
| RE-09 | Usability-test moderation | Runs task-based sessions, probes behavior, and avoids coaching participants. | P | O | P | L | UX |
| RE-10 | Research synthesis | Clusters observations into findings, confidence levels, tensions, and implications. | P | O | L | L | UX |
| RE-11 | Insight communication | Communicates evidence through concise narratives, artifacts, clips, and direct implications. | O | O | P | L | UX |
| RE-12 | Research-repository stewardship | Makes evidence findable, traceable, current, and reusable across teams. | P | P | L | L | UX |
