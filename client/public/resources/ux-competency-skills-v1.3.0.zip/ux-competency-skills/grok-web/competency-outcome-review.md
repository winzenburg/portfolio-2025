---
name: competency-outcome-review
description: "Review whether shipped product, design, or front-end work delivered its expected value and turn it into a case study. Use after a release, at the end of an engagement, for a retrospective, or when writing a portfolio or sales case study. Produces the evidence → decision → constraints → shipped behavior → measured outcome narrative."
metadata:
  pack: ux-competency-skills
  version: "1.3.0"
---

# Outcome review

## Steps
1. Pull the expected outcomes from `brief.md` / `product-brief.md` and the metrics from `measurement-plan.md`.
2. Collect actual results: metrics, qualitative feedback, quality data (defects, incidents, accessibility issues, performance).
3. Compare expected vs actual. State the gap and confidence. Separate the effect of this work from other changes where you can (ME-08, ME-09).
4. Decide: scale, iterate, or stop (ME-12). Name the owner and date.
5. Write the case-study chain below. Map each link to the skill IDs it demonstrates.
6. Update `audit.md` scores if the work produced new evidence.

## Output: `outcome-review.md`
- Expected outcomes and metrics
- Actual results and confidence
- Decision and next step
- **Case study chain**
  1. Evidence — what we learned and how (RE, ME)
  2. Decision — what we chose and the trade-off (PB, LG)
  3. Implementation constraints — what reality changed (PR, FE, AR)
  4. Shipped behavior — what users now experience (IA, UI, CX, AX, DS)
  5. Measured outcome — the number, the quote, the change (ME)
- Skills demonstrated (IDs)
- What we'd do differently

## Rules
- Lead with the business outcome, not the method.
- Use real numbers with their source; no invented metrics. If a number is missing, say so.
- Protect client confidentiality: anonymize names and figures unless cleared.

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
