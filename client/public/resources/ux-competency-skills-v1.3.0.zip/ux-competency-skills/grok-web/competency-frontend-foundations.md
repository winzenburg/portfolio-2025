---
name: competency-frontend-foundations
description: "Use automatically, without being asked, whenever a task involves front-end foundations: semantic HTML, CSS cascade and layers, Grid/Flexbox, container queries, responsive implementation, TypeScript, DOM events and focus, browser APIs, routing, framework lifecycle, dependency evaluation, build tooling, animation (CSS, GSAP, Motion), or Canvas/WebGL/3D. Applies competency skills FE-01–FE-14 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs implementation-notes.md."
metadata:
  pack: ux-competency-skills
  version: "1.3.0"
---

# Front-end foundations and browser-platform fluency (FE)

**Goal:** Implement the experience on the web platform correctly before reaching for abstractions.

Skills covered: 14 (see the appendix below for evidence, depth, and lead per role). Lead roles in this domain: FE Arch (14).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in the appendix below and note which role leads each.

## Procedure
1. Read the existing codebase conventions first (framework, styling approach, lint rules) and follow them.
2. Structure: landmarks, heading order, forms with labels, correct metadata (FE-01).
3. Styling: predict the cascade; use layers or scoping; avoid specificity fights (FE-02).
4. Layout: Grid for two-dimensional, Flexbox for one; intrinsic sizing; container queries for components; logical properties (FE-03, FE-04).
5. TypeScript: typed boundaries for data, explicit error handling for async code (FE-05).
6. Events: handle keyboard and pointer equally; manage focus on route and modal changes (FE-06).
7. Browser APIs: pick the least powerful API that works; check support and permission prompts (FE-07).
8. Native elements first; custom widgets follow the ARIA Authoring Practices pattern (FE-08).
9. Routing: deep-linkable state, guards, back-button behavior, not-found and error routes (FE-09).
10. Know the framework's render and effect lifecycle; clean up subscriptions (FE-10).
11. Motion: animate transform and opacity, keep animations interruptible, honor prefers-reduced-motion, and check INP/frame cost (FE-13).
12. Canvas/WebGL/3D only when it serves the experience; lazy-load it, cap device cost, and provide a static or accessible fallback (FE-14).
13. Before adding a dependency: purpose, size, license, maintenance, security (FE-11). Keep build, lint, test, and format scripts working (FE-12).
14. Stack notes: follow the repo. Tailwind v4 keeps tokens in CSS (@theme); shadcn/ui copies components into your codebase, so you own and must maintain them; animation libraries (GSAP, Motion, anime.js) are FE-13 tools, not requirements.

## Method selector
| Situation | Use |
|---|---|
| Component breaks at some widths | Container queries + intrinsic sizing |
| Styles override unpredictably | Cascade layers or scoped styles |
| Focus lost after navigation or modal | Explicit focus management (FE-06) |
| Tempted to add a library | FE-11 checklist first |
| Scroll-driven storytelling | CSS scroll-driven animations first; a library only if needed (FE-13) |

## Output: `implementation-notes.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Conventions followed
- Semantic structure
- Layout approach
- Focus management
- Dependencies added and why
- Known limitations

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Clickable div | Use <button> or <a> |
| !important chains | Fix the cascade instead |
| any types at API boundaries | Type and validate the payload |
| Viewport breakpoints for component layout | Container queries |

## Hand off to
- competency-frontend-architecture
- competency-accessibility
- competency-quality-reliability

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.

---

## Appendix: references/skills.md

### Front-end foundations and browser-platform fluency (FE) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| FE-01 | HTML document structure | Builds a correct document outline, landmarks, metadata, forms, and content hierarchy. | L | P | P | O | FE Arch |
| FE-02 | CSS cascade reasoning | Predicts inheritance, specificity, layers, scope, and resulting style behavior. | L | L | P | O | FE Arch |
| FE-03 | Modern layout implementation | Uses Grid, Flexbox, intrinsic sizing, container-aware behavior, and logical properties appropriately. | L | P | P | O | FE Arch |
| FE-04 | Responsive implementation | Implements fluid layouts, appropriate breakpoints, media features, and viewport behavior. | L | P | P | O | FE Arch |
| FE-05 | JavaScript and TypeScript fluency | Uses types, data transformation, async patterns, modules, and error handling safely. | L | L | L | O | FE Arch |
| FE-06 | DOM and event-model reasoning | Handles propagation, delegation, focus, input, pointer, keyboard, and lifecycle interactions correctly. | L | P | P | O | FE Arch |
| FE-07 | Browser API selection | Chooses browser capabilities such as storage, observers, workers, history, clipboard, and media APIs responsibly. | — | L | L | O | FE Arch |
| FE-08 | Semantic component implementation | Prefers native elements and exposes accessible semantics when custom behavior is necessary. | L | P | P | O | FE Arch |
| FE-09 | Client-side routing | Implements route structure, deep links, parameters, guards, navigation state, and recovery. | L | L | L | O | FE Arch |
| FE-10 | Framework lifecycle knowledge | Understands rendering, effects, hydration, reactivity, suspense, and cleanup in the chosen stack. | — | L | L | O | FE Arch |
| FE-11 | Package and dependency literacy | Evaluates package purpose, quality, license, maintenance, bundle cost, and security posture. | — | L | L | O | FE Arch |
| FE-12 | Build-tool fluency | Configures development, test, build, lint, formatting, environment, and deployment workflows. | — | L | L | O | FE Arch |
| FE-13 | Motion implementation | Implements animation with compositor-friendly properties, interruptible timing, scroll-driven techniques, and reduced-motion support inside performance budgets. | — | L | P | O | FE Arch |
| FE-14 | Immersive graphics | Uses Canvas, SVG, WebGL/3D, and physics libraries only when they serve the experience, with fallbacks, performance limits, and accessible alternatives. | — | L | P | O | FE Arch |
