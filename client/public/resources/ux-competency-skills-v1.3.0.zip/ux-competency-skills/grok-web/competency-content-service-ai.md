---
name: competency-content-service-ai
description: "Use automatically, without being asked, whenever a task involves content, service, and AI interaction: UX writing, microcopy, error messages, empty states, notifications, onboarding, terminology, localization, service blueprints, conversational UI, AI confidence and provenance, human-in-the-loop, or AI evals. Applies competency skills CX-01–CX-13 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs content-and-ai-spec.md."
metadata:
  pack: ux-competency-skills
  version: "1.3.0"
---

# Content design, service design, and AI interaction design (CX)

**Goal:** Make words, services, and AI behavior trustworthy and actionable.

Skills covered: 13 (see the appendix below for evidence, depth, and lead per role). Lead roles in this domain: UX (7), Product (5), FE Arch (1).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in the appendix below and note which role leads each.

## Procedure
1. Build or check the glossary: one term per concept, in user language, matched to the domain model (CX-03).
2. Write labels and instructions for the task, front-loaded and short (CX-01, CX-02).
3. Error messages: what happened, why if it helps, what to do now, where to get help (CX-04).
4. Empty states: orientation, value, next action — or an honest reason nothing can be done yet (CX-05).
5. Notifications: trigger, audience, channel, timing, priority, frequency cap, user preference (CX-06).
6. Onboarding: progressive setup tied to the activation event; no mandatory tours (CX-07).
7. Blueprint the service across front stage and backstage when more than one channel or team is involved (CX-11).
8. For AI features: show confidence and sources, state limits, suggest verification (CX-09); assign automate / review / escalate / override to named actors (CX-10); define the eval set and release threshold before launch (CX-13); design turn-taking, repair, and exit for conversational flows (CX-08).
9. Check for localization: text expansion (+30–40%), RTL, locale formats, no text in images (CX-12).

## Method selector
| Situation | Use |
|---|---|
| AI output can be wrong in costly ways | CX-10 human review + CX-09 provenance + CX-13 eval gate |
| Users ignore notifications | CX-06 audit: fatigue, relevance, channel |
| Many teams touch the journey | CX-11 service blueprint first |
| Terminology fights | CX-03 glossary with owner and decision log |

## Output: `content-and-ai-spec.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Glossary
- Copy deck (labels, errors, empty states)
- Notification matrix
- Onboarding path
- Service blueprint
- AI behavior spec: confidence, provenance, HITL roles, evals, fallbacks

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| "Something went wrong" errors | Name the problem and the recovery action |
| AI answer shown with no source or confidence | Add provenance and a verification prompt |
| Automation with no override | Every automated action needs a human reversal path |
| Evals written after launch | No release without an agreed threshold |

## Hand off to
- competency-accessibility (cognitive accessibility)
- competency-leadership-governance (AI governance, LG-12)
- competency-quality-reliability (fallback and incident handling)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.

---

## Appendix: references/skills.md

### Content design, service design, and AI interaction design (CX) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| CX-01 | UX writing | Produces concise, task-oriented labels, instructions, status, and error content. | P | O | P | L | UX |
| CX-02 | Content hierarchy | Determines what users need now, later, or never; structures for scanning and action. | P | O | P | L | UX |
| CX-03 | Terminology governance | Maintains a controlled vocabulary that matches user language and domain semantics. | P | O | P | P | UX |
| CX-04 | Error-message design | States the problem, cause when useful, recovery action, and durable support path. | P | O | P | P | UX |
| CX-05 | Empty-state design | Gives clear orientation, value, next action, and legitimate reason when no action exists. | P | O | O | P | UX |
| CX-06 | Notification design | Sets event triggers, audience, channel, timing, priority, fatigue protections, and user preferences; defines delivery requirements for engineering. | P | O | P | P | UX |
| CX-07 | Onboarding design | Designs progressive learning, setup, activation, and return paths without forcing needless tours. | O | O | P | P | Product |
| CX-08 | Conversational interaction design | Defines turn-taking, intent repair, confirmation, memory boundaries, and exit paths. | P | O | P | P | UX |
| CX-09 | AI uncertainty communication | Represents confidence, source/provenance, limitations, and recommended verification in AI outputs. | O | O | P | O | Product |
| CX-10 | Human-in-the-loop workflow design | Assigns automation, review, escalation, override, and accountability to the right actor. | O | P | L | O | Product |
| CX-11 | Service-design orchestration | Creates the cross-channel service blueprint spanning people, processes, policies, and technology, including backstage failure modes. | P | P | L | P | Product |
| CX-12 | Localization-ready design | Anticipates language expansion, bidirectionality, locale formats, cultural conventions, and translation workflow. | P | P | P | O | FE Arch |
| CX-13 | AI evaluation design | Defines task-representative eval sets, quality rubrics, failure taxonomies, and release thresholds for AI-generated output; reruns them on every model or prompt change. | O | P | L | O | Product |
