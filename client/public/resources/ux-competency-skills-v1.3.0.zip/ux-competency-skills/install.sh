#!/usr/bin/env bash
# Install the UX Competency Skills Pack into Cursor and/or Grok Build.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$HERE/skills"
STAMP="$(date +%Y%m%d%H%M%S)"

# Backups go OUTSIDE the skills folder so the agent never loads them as duplicates.
backup() {
  local bdir; bdir="$(dirname "$1")/skills-backup-$STAMP"; mkdir -p "$bdir"
  mv "$1/$2" "$bdir/$2"
}
copy_to() {
  local dest="$1"; mkdir -p "$dest"
  for s in "$SRC"/*/; do
    n="$(basename "$s")"
    if [ -e "$dest/$n" ] || [ -L "$dest/$n" ]; then backup "$dest" "$n"; fi
    cp -R "$s" "$dest/$n"
  done
  echo "Installed $(ls -d "$SRC"/*/ | wc -l | tr -d ' ') skills -> $dest"
}
link_to() {
  local dest="$1"; mkdir -p "$dest"
  for s in "$SRC"/*/; do
    n="$(basename "$s")"
    if [ -e "$dest/$n" ] || [ -L "$dest/$n" ]; then backup "$dest" "$n"; fi
    ln -s "${s%/}" "$dest/$n"
  done
  echo "Linked skills -> $dest"
}

case "${1:-}" in
  cursor)        copy_to "$HOME/.cursor/skills" ;;
  grok)          copy_to "$HOME/.grok/skills" ;;
  both)          copy_to "$HOME/.cursor/skills"; copy_to "$HOME/.grok/skills" ;;
  link)          link_to "$HOME/.cursor/skills"; link_to "$HOME/.grok/skills" ;;
  cursor-global)
                 link_to "$HOME/.cursor/skills"
                 if command -v pbcopy >/dev/null; then pbcopy < "$HERE/cursor/user-rule.txt"; echo "User Rule copied to clipboard."; else echo "User Rule text: $HERE/cursor/user-rule.txt"; fi
                 echo "Next: Cursor → Customize → Rules → User Rules → paste. Then restart Cursor." ;;
  project)       copy_to "${2:?repo path}/.agents/skills" ;;
  grok-project)  copy_to "${2:?repo path}/.grok/skills" ;;
  *) echo "usage: $0 {cursor-global|cursor|grok|both|link|project <repo>|grok-project <repo>}"; exit 1 ;;
esac
