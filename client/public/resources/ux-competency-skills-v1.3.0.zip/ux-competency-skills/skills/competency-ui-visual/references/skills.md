# UI design and visual systems (UI) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| UI-01 | Visual hierarchy | Directs attention using contrast, scale, placement, grouping, and motion. | P | P | O | P | UI |
| UI-02 | Layout composition | Creates balanced, purposeful compositions with grid, alignment, rhythm, and responsive intent. | P | P | O | P | UI |
| UI-03 | Typography systems | Selects type scales, roles, weights, line lengths, and responsive behavior for legibility. | P | P | O | P | UI |
| UI-04 | Color-system design | Establishes semantic color roles, contrast, states, dark-mode behavior, and theming logic. | P | P | O | P | UI |
| UI-05 | Spacing and sizing systems | Defines scalable spatial relationships rather than arbitrary per-screen measurements. | P | P | O | O | UI |
| UI-06 | Iconography direction | Chooses or creates icons with clear metaphor, optical balance, labeling strategy, and accessibility. | L | P | O | P | UI |
| UI-07 | Visual affordance design | Makes controls, hierarchy, interactivity, and action consequence perceptible. | P | O | O | P | UI |
| UI-08 | Responsive visual adaptation | Preserves priority and comprehension across viewports and input modes. | P | P | O | O | UI |
| UI-09 | Data-display design | Chooses tables, charts, cards, maps, and annotations that support comparison and decisions. | P | P | O | P | UI |
| UI-10 | Data-dense interface design | Handles scanning, density, grouping, pinned context, exceptions, and progressive disclosure. | O | O | O | O | Product |
| UI-11 | Brand-to-product translation | Applies brand expression without damaging usability, density, or accessibility. | P | P | O | P | UI |
| UI-12 | Motion and transition design | Specifies motion only where it explains change or marks a brand moment: duration, easing or spring, interruptibility, continuity, reduced-motion behavior, and implementation intent. | P | P | O | P | UI |
| UI-13 | Visual direction | Defines a distinctive, justified aesthetic point of view (type pairing, color mood, imagery and illustration style, composition) and sources imagery with clear licensing; avoids generic defaults. | P | L | O | L | UI |
| UI-14 | Interface polish | Resolves craft details: optical alignment, hover/press/focus states, skeletons, elevation and shadow scale, tabular numerals, type cleanup, and consistent micro-spacing. | L | P | O | O | UI |
