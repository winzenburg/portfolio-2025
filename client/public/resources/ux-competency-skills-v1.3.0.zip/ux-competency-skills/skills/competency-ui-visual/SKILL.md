---
name: competency-ui-visual
description: "Use automatically, without being asked, whenever a task involves UI and visual systems: visual hierarchy, layout, typography, color, spacing, iconography, affordance, responsive design, data tables and charts, data-dense enterprise screens, brand application, visual/art direction, making a UI look less generic, polish and craft details, or motion design. Applies competency skills UI-01–UI-14 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs ui-spec.md."
metadata:
  pack: ux-competency-skills
  version: "1.3.0"
---

# UI design and visual systems (UI)

**Goal:** Make the interface legible and scannable at the density the work requires.

Skills covered: 14 (see `references/skills.md` for evidence, depth, and lead per role). Lead roles in this domain: UI (13), Product (1).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in `references/skills.md` and note which role leads each.

## Procedure
1. Rank everything on the screen: primary action, primary information, secondary, tertiary. Hierarchy follows that ranking (UI-01).
2. Lay out on the grid; use consistent alignment and rhythm; decide what reflows at each container size (UI-02, UI-08).
3. Apply the type scale by role (display, heading, body, label, data), check line length and numeric alignment (UI-03).
4. Use semantic color roles (surface, text, border, accent, success, warning, danger, info) with contrast verified in light and dark (UI-04, AX-07).
5. Use spacing tokens, never ad-hoc values (UI-05).
6. Make interactive elements look interactive and consequences visible (UI-07).
7. For data: pick the display by the question — compare, trend, part-to-whole, locate, inspect (UI-09).
8. For data-dense screens: pinned context, row density options, column priority, exception highlighting, progressive disclosure (UI-10).
9. Set the visual direction before styling: type pairing, color mood, imagery style, composition. Write it as 3–5 rules with a reason each; source imagery with clear licensing (UI-13).
10. Motion only where it explains change or marks a brand moment; specify duration, easing or spring, interruptibility, and reduced-motion behavior (UI-12). Implementation goes to FE-13.
11. Polish pass: optical alignment, hover/press/focus states, skeletons, elevation scale, tabular numerals for data, type cleanup (UI-14).

## Method selector
| Situation | Use |
|---|---|
| Screen feels cluttered | Re-rank content (UI-01), then remove or disclose |
| Enterprise table with 20+ columns | UI-10: column priority, pinning, density toggle, saved views |
| Brand wants expression | UI-11: apply brand at surfaces and moments, not inside dense controls |
| Choosing a chart | UI-09: question first, then form |
| Output looks generic or 'AI-made' | UI-13 direction rules, then UI-14 polish pass |
| Marketing page vs product workflow | Expressive direction on marketing surfaces; legibility and density win inside workflows |

## Output: `ui-spec.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Hierarchy ranking
- Layout and responsive rules
- Type, color, spacing tokens used
- Component list
- Data display choices
- Motion spec
- Visual QA checklist

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Everything is bold or colored | One primary emphasis per region |
| Color alone signals status | Add icon, text, or shape (AX-06) |
| Hard-coded hex and px values | Map to tokens (DS-04) |
| Dense screen made 'clean' by hiding needed data | Density is a user need; design for scanning instead |
| Opinionated style preset overrides the product's system | Project tokens win; presets only when no system exists |

## Hand off to
- competency-design-systems
- competency-accessibility
- competency-prototyping-handoff

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
