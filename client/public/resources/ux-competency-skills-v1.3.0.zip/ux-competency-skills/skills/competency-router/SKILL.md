---
name: competency-router
description: "Use automatically at the start of any product, UX, UI, design-system, marketing-page, or front-end task that spans more than one discipline, is ambiguous, or needs a plan. Also use it to say which competency or role applies, look up a skill ID (e.g. PB-03, AX-08), or plan a chain of skills for a playbook such as a consulting diagnostic, MVP, feature build, data-dense redesign, AI feature, design-system rescue, accessibility remediation, front-end health check, marketing site and conversion, UI polish pass, pressure test, or team capability assessment."
metadata:
  pack: ux-competency-skills
  version: "1.3.0"
---

# Competency router

Classify the request, pick the playbook, and run the chain. Do not do domain work here; hand off.

## Steps
0. Size the request. If one domain skill covers it, hand off to that skill immediately and stop here — no brief, no plan.
1. Write a 3-line brief: product and users · decision or deliverable wanted · constraints (deadline, stack, regulation). Read the repo (README, package.json, existing design tokens) instead of asking when you can. Save as `docs/competency/brief.md` if you can write files.
2. Match the request to a playbook below. If none fits, pick domains from the routing table.
3. If the request is an assessment ("how good is…", "where are the gaps"), start with `competency-audit`.
4. Write `docs/competency/plan.md`: ordered skills, skill IDs, business outcome each step serves, artifact path.
5. Run the first skill. After each skill, log it in `chain-log.md` and move to the next.
6. Finish with `competency-outcome-review` for anything that ships.

For a lookup question ("what is IA-07?", "who leads DS-04?"), answer from `references/taxonomy.md` and stop.

## Routing table
| Prefix | Domain | Skill | Use for |
|---|---|---|---|
| PB | Product framing, business, and systems thinking | `competency-product-framing` | frame a problem, define outcomes, map assumptions, size an opportunity, write a value proposition, JTBD, prioritize a backlog, design an experiment, or explain a trade-off |
| RE | User research and evidence synthesis | `competency-user-research` | plan research, write an interview guide, run or analyze usability tests, contextual inquiry, task analysis, surveys, diary studies, synthesize findings, or build a research repository |
| IA | Information architecture and interaction design | `competency-ia-interaction` | design navigation, taxonomy, search and filters, user flows, task flows, forms, interaction states, error prevention, feedback/status, interaction patterns, or iOS/Android/web platform conventions |
| CX | Content design, service design, and AI interaction design | `competency-content-service-ai` | UX writing, microcopy, error messages, empty states, notifications, onboarding, terminology, localization, service blueprints, conversational UI, AI confidence and provenance, human-in-the-loop, or AI evals |
| UI | UI design and visual systems | `competency-ui-visual` | visual hierarchy, layout, typography, color, spacing, iconography, affordance, responsive design, data tables and charts, data-dense enterprise screens, brand application, visual/art direction, making a UI look less generic, polish and craft details, or motion design |
| AX | Accessibility, inclusion, and responsible experience design | `competency-accessibility` | accessibility, a11y, WCAG, keyboard navigation, screen readers, ARIA, contrast, accessible forms, captions, cognitive load, touch targets, or accessibility audits and remediation |
| DS | Design systems and design operations | `competency-design-systems` | design system, component library, design tokens, token naming, theming, component anatomy or API, pattern library, documentation, contribution model, visual regression, adoption, design debt, or extracting a design system from an existing product or site |
| PR | Prototyping, specification, and design-to-code collaboration | `competency-prototyping-handoff` | prototype, pick prototype fidelity, write interaction specs, responsive specs, edge cases, acceptance criteria, design handoff, design QA, checking built UI in the browser with screenshots, or design-engineering pairing |
| FE | Front-end foundations and browser-platform fluency | `competency-frontend-foundations` | semantic HTML, CSS cascade and layers, Grid/Flexbox, container queries, responsive implementation, TypeScript, DOM events and focus, browser APIs, routing, framework lifecycle, dependency evaluation, build tooling, animation (CSS, GSAP, Motion), or Canvas/WebGL/3D |
| AR | Front-end architecture and application systems | `competency-frontend-architecture` | application structure, module boundaries, component composition, state management, data fetching and caching, API contracts, SSR/SSG/streaming choice, auth states, feature flags, error boundaries, ADRs, or front-end technical roadmap |
| QL | Quality engineering, performance, reliability, privacy, and security | `competency-quality-reliability` | test strategy, unit/integration/e2e tests, accessibility automation, cross-browser testing, Core Web Vitals, performance budgets, offline and resilience, logging and observability, client security, privacy, or incident response |
| ME | Measurement, optimization, and operational learning | `competency-measurement` | north-star metric, KPIs, measurement plan, event schema, analytics instrumentation, funnels, cohorts, segmentation, A/B test analysis, product health report, continuous discovery, or whether a release delivered value |
| GM | Growth, conversion, and marketing surfaces | `competency-growth-conversion` | landing pages, homepage or features pages, conversion copy, pricing pages, paywalls and upgrade prompts, social proof and demos, CRO tests, SEO or AI-search (GEO) visibility, brand strategy for the site, or getting first users |
| LG | Collaboration, leadership, governance, and professional judgment | `competency-leadership-governance` | stakeholder alignment, workshop facilitation, design or technical critique, executive readout, influencing without authority, resolving conflict, estimation, risk register, ethics review, AI governance, AI-augmented team practice, writing prompts or agent skills, or pressure-testing a plan |

Also in the pack: `competency-audit` (gap assessment) and `competency-outcome-review` (post-release value and case study).

## Playbooks
| Playbook | Chain | Business outcome |
|---|---|---|
| Consulting diagnostic | audit → leadership-governance (LG-06 readout) | Prioritized risk and a scoped proposal |
| New product / MVP | product-framing → user-research → ia-interaction → ui-visual → prototyping-handoff → measurement | Validated concept before build spend |
| Feature build | product-framing → ia-interaction → content-service-ai → prototyping-handoff → frontend-foundations → quality-reliability → outcome-review | Shipped feature with measured result |
| Enterprise data-dense workflow redesign | user-research (RE-04/05) → ia-interaction → ui-visual (UI-10) → accessibility → frontend-architecture → measurement → outcome-review | Higher task completion, fewer errors |
| AI-assisted feature | product-framing → content-service-ai (CX-09/10/13) → leadership-governance (LG-12) → prototyping-handoff → quality-reliability → measurement | Trustworthy automation with controls |
| Design system rescue | audit (DS) → design-systems → frontend-architecture (AR-02) → accessibility | Faster delivery, consistent UI |
| Accessibility remediation | audit (AX) → accessibility → design-systems → quality-reliability (QL-04) | Reduced legal and usability risk |
| Front-end codebase health check | audit (FE/AR/QL) → frontend-architecture → quality-reliability → leadership-governance (ADRs, roadmap) | Lower change cost and incident rate |
| Team capability assessment | audit (people mode) → leadership-governance | Hiring and development plan |
| Marketing site / conversion | product-framing → growth-conversion → ui-visual (UI-13/14) → accessibility → quality-reliability (QL-07) → measurement | More qualified signups and upgrades |
| UI polish pass | audit (UI/DS) → ui-visual (UI-14) → prototyping-handoff (PR-13) | Higher perceived quality, fewer visual defects |
| Pressure test | leadership-governance (LG-03 pressure-test mode) → product-framing (update assumptions) | Weak assumptions found before spend |
| Outcome review / case study | measurement → outcome-review | Proof of value; sales-ready story |

## Rules
- Don't ask the user which skill to use. Pick it from the routing table; mention the skill name in one line so they can redirect.
- Sell and frame every step by business outcome (reduced risk, clearer direction, better conversion, added capacity), not by activity.
- Accessibility (AX) and leadership/governance (LG) are cross-cutting: check them in every chain.
- Keep the chain short. Skip a domain only with a stated reason in `plan.md`.

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
