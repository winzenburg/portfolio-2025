# Front-end architecture and application systems (AR) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| AR-01 | Application decomposition | Separates pages, features, domains, shared UI, utilities, and platform layers with clear boundaries. | L | L | L | O | FE Arch |
| AR-02 | Component-composition strategy | Chooses local versus shared components and controls abstraction before reuse becomes accidental coupling. | L | P | P | O | FE Arch |
| AR-03 | State-model design | Defines server, client, URL, form, cache, and transient UI state with a single clear owner. | L | P | L | O | FE Arch |
| AR-04 | Data-fetching architecture | Handles caching, invalidation, loading, errors, retry, pagination, optimistic updates, and consistency. | L | L | L | O | FE Arch |
| AR-05 | API contract collaboration | Designs client needs, payload shapes, versioning, error semantics, and backwards-compatibility with API teams. | P | L | L | O | FE Arch |
| AR-06 | Rendering-strategy selection | Chooses client, server, static, streaming, or hybrid rendering based on latency, SEO, personalization, and operations. | L | L | L | O | FE Arch |
| AR-07 | Authentication and authorization UX implementation | Implements identity, session, role, permission, expiry, reauthentication, and access-denied states safely. | P | P | P | O | FE Arch |
| AR-08 | Feature-flag architecture | Supports targeted rollout, kill switches, experiment assignment, configuration, and flag cleanup. | P | L | L | O | FE Arch |
| AR-09 | Error-boundary and recovery architecture | Contains failures, preserves useful context, supports retry, and avoids blank-screen failure modes. | L | P | P | O | FE Arch |
| AR-10 | Codebase modularity | Keeps code independently understandable, testable, deployable, and changeable as product complexity grows. | — | L | L | O | FE Arch |
| AR-11 | Architectural decision records | Captures context, alternatives, decision, consequences, and revisit triggers for consequential choices. | L | L | L | O | FE Arch |
| AR-12 | Technical roadmapping | Sequences platform investments, migrations, risk reduction, and capability building against product strategy. | P | L | L | O | FE Arch |
