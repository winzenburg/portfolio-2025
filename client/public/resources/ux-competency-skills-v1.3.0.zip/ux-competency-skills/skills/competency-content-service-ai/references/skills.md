# Content design, service design, and AI interaction design (CX) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| CX-01 | UX writing | Produces concise, task-oriented labels, instructions, status, and error content. | P | O | P | L | UX |
| CX-02 | Content hierarchy | Determines what users need now, later, or never; structures for scanning and action. | P | O | P | L | UX |
| CX-03 | Terminology governance | Maintains a controlled vocabulary that matches user language and domain semantics. | P | O | P | P | UX |
| CX-04 | Error-message design | States the problem, cause when useful, recovery action, and durable support path. | P | O | P | P | UX |
| CX-05 | Empty-state design | Gives clear orientation, value, next action, and legitimate reason when no action exists. | P | O | O | P | UX |
| CX-06 | Notification design | Sets event triggers, audience, channel, timing, priority, fatigue protections, and user preferences; defines delivery requirements for engineering. | P | O | P | P | UX |
| CX-07 | Onboarding design | Designs progressive learning, setup, activation, and return paths without forcing needless tours. | O | O | P | P | Product |
| CX-08 | Conversational interaction design | Defines turn-taking, intent repair, confirmation, memory boundaries, and exit paths. | P | O | P | P | UX |
| CX-09 | AI uncertainty communication | Represents confidence, source/provenance, limitations, and recommended verification in AI outputs. | O | O | P | O | Product |
| CX-10 | Human-in-the-loop workflow design | Assigns automation, review, escalation, override, and accountability to the right actor. | O | P | L | O | Product |
| CX-11 | Service-design orchestration | Creates the cross-channel service blueprint spanning people, processes, policies, and technology, including backstage failure modes. | P | P | L | P | Product |
| CX-12 | Localization-ready design | Anticipates language expansion, bidirectionality, locale formats, cultural conventions, and translation workflow. | P | P | P | O | FE Arch |
| CX-13 | AI evaluation design | Defines task-representative eval sets, quality rubrics, failure taxonomies, and release thresholds for AI-generated output; reruns them on every model or prompt change. | O | P | L | O | Product |
