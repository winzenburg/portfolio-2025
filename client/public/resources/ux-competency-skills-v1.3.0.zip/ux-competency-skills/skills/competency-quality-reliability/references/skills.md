# Quality engineering, performance, reliability, privacy, and security (QL) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| QL-01 | Unit-test design | Tests important logic and behavior with isolated, maintainable cases. | — | L | L | O | FE Arch |
| QL-02 | Integration-test design | Verifies components, state, data, and services working together at meaningful seams. | L | L | L | O | FE Arch |
| QL-03 | End-to-end test design | Automates critical user journeys with stable fixtures, assertions, and failure diagnostics. | P | P | L | O | FE Arch |
| QL-04 | Accessibility-test automation | Integrates automated scanning while recognizing where manual evaluation is required. | L | P | P | O | FE Arch |
| QL-05 | Cross-browser and device testing | Selects and validates browsers, OS, viewport, input, and assistive-technology coverage by risk. | L | P | P | O | FE Arch |
| QL-06 | Performance measurement | Reads and diagnoses field and lab performance data (Core Web Vitals: LCP, INP, CLS), traces, bundle composition, and runtime bottlenecks. | L | L | L | O | FE Arch |
| QL-07 | Performance-budget management | Defines and enforces thresholds for script and style payload, images and fonts, rendering, interaction, and animation cost. | L | L | L | O | FE Arch |
| QL-08 | Resilience and offline design | Handles intermittent connectivity, retries, queues, persistence, stale data, and graceful degradation. | P | P | L | O | FE Arch |
| QL-09 | Observability instrumentation | Produces meaningful logs, errors, traces, user context, and dashboards while protecting privacy. | L | L | L | O | FE Arch |
| QL-10 | Client-side security | Prevents common client exposure through secure rendering, dependency hygiene, token handling, and safe browser APIs. | L | L | L | O | FE Arch |
| QL-11 | Privacy-by-design implementation | Minimizes collection, supports consent and retention requirements, and avoids exposing sensitive data in telemetry. | P | P | L | O | FE Arch |
| QL-12 | Incident participation | Triages defects, communicates impact, mitigates safely, runs blameless review, and prevents recurrence. | P | L | L | O | FE Arch |
