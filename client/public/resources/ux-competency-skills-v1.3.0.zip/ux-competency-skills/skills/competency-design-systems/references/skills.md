# Design systems and design operations (DS) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| DS-01 | System scope definition | Defines the products, platforms, users, adoption goals, and non-goals of a system. | P | P | O | O | UI |
| DS-02 | Component anatomy design | Defines stable parts, slots, behaviors, states, and content rules for a component. | P | P | O | O | UI |
| DS-03 | Component API design | Designs composable, discoverable, constrained component props and events without leaking implementation detail. | L | P | P | O | FE Arch |
| DS-04 | Design-token architecture | Creates primitive, semantic, and component tokens with clear aliasing and theming rules. | P | P | O | O | FE Arch |
| DS-05 | Token naming | Uses names that express purpose, scope, and state rather than present implementation values. | P | P | O | O | UI |
| DS-06 | Pattern-library curation | Distinguishes reusable patterns from one-off solutions and maintains a coherent catalog. | P | P | O | O | UI |
| DS-07 | System documentation | Documents usage, anatomy, do/don't guidance, accessibility, content, code, and change status. | P | P | O | O | UI |
| DS-08 | Contribution-model design | Defines proposal, review, implementation, release, and ownership mechanisms for changes. | P | P | O | O | UI |
| DS-09 | Visual-regression governance | Establishes baselines, diff review, exception criteria, and remediation ownership. | L | L | P | O | FE Arch |
| DS-10 | Cross-platform consistency | Maps intent across web, mobile, email, native, and brand contexts without forcing identical controls. | P | P | O | O | UI |
| DS-11 | System adoption enablement | Builds training, migration support, champions, examples, and measurement to drive use. | P | P | O | P | UI |
| DS-12 | Design-debt management | Identifies, sizes, sequences, and funds inconsistency and maintainability reduction. | O | P | O | O | Product |
| DS-13 | Design-system extraction | Derives tokens, type scale, components, and patterns from an existing product or site into a starter system, limited to owned, client, or licensed sources. | L | P | O | O | UI |
