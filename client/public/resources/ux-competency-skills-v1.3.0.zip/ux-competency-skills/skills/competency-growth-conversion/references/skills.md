# Growth, conversion, and marketing surfaces (GM) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| GM-01 | Landing-page architecture | Structures a page around one audience, one promise, proof, objections, and one primary action. | O | P | O | P | Product |
| GM-02 | Conversion copywriting | Writes headlines, value propositions, CTAs, and objection handling in customer language; distinct from task-focused UX writing (CX-01). | O | P | L | — | Product |
| GM-03 | Pricing-page design | Presents plans, comparison, billing options, FAQs, and the enterprise path so buyers can choose without a sales call. | O | P | O | L | Product |
| GM-04 | Upgrade and paywall design | Places upgrade moments at points of realized value, previews paid value, and never blocks core work or hides the free path. | O | O | P | P | Product |
| GM-05 | Proof design | Uses real product UI, workflow demos, verifiable metrics, logos, and attributable testimonials as evidence. | O | P | O | P | Product |
| GM-06 | Ethical persuasion design | Applies behavioral principles (clarity, anchoring, social proof, defaults) and rejects deceptive patterns such as fake scarcity, confirmshaming, and hidden costs. | O | O | P | L | Product |
| GM-07 | Conversion experiment program | Maintains a hypothesis backlog, prioritizes tests, and runs experiments on acquisition and upgrade surfaces; analysis per ME-08. | O | P | L | P | Product |
| GM-08 | Search and AI-answer discoverability | Ships semantic structure, metadata, structured data, crawlable rendering, fast media, and citable content for search engines and AI answers (SEO/GEO). | P | P | L | O | FE Arch |
| GM-09 | Brand strategy translation | Turns positioning, voice, and identity rules into site and product guidance, in partnership with brand owners; application in product stays UI-11. | O | P | O | L | Product |
| GM-10 | Launch and early-traction design | Designs first-user channels, activation paths, and feedback loops for zero-to-one products. | O | P | L | L | Product |
