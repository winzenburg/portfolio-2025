# Prototyping, specification, and design-to-code collaboration (PR) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| PR-01 | Low-fidelity prototyping | Uses rough artifacts to test structure, flow, and language before visual polish. | O | O | P | L | UX |
| PR-02 | High-fidelity prototyping | Models visual states, interaction, feedback, and responsive intent at decision-ready fidelity. | O | O | O | P | UI |
| PR-03 | Prototype selection | Chooses paper, clickable, coded, data-backed, or service prototype according to the risk being tested. | O | O | P | P | UX |
| PR-04 | Prototype realism calibration | Includes enough realistic data, latency, content, and errors to avoid false-positive learning. | P | O | P | O | UX |
| PR-05 | Interaction specification | Documents triggers, state transitions, rules, animation, input behavior, and exceptions. | P | O | O | O | UX |
| PR-06 | Responsive specification | Specifies breakpoints or container behavior, reflow, priority changes, and density adjustments. | P | P | O | O | UI |
| PR-07 | Edge-case specification | Defines empty, loading, error, permission, long-content, unusual-data, and degraded-mode behavior. | O | O | O | O | Product |
| PR-08 | Acceptance-criteria writing | Expresses user-visible requirements and observable conditions for completion. | O | P | P | O | Product |
| PR-09 | Design handoff | Supplies intent, system references, state rules, assets, and examples without pretending screenshots are specifications. | P | P | O | O | UI |
| PR-10 | Engineer-design pairing | Resolves ambiguity live, compares alternatives, and protects outcome while adapting implementation. | O | O | P | O | FE Arch |
| PR-11 | Design QA | Detects and prioritizes deviations across function, layout, content, states, accessibility, and responsiveness. | P | P | O | O | UI |
| PR-12 | Implementation feedback incorporation | Updates design artifacts after discovery of real platform constraints or new learning. | O | O | O | O | Product |
| PR-13 | Rendered-UI verification | Checks the built UI in a real browser across viewports, themes, and states with screenshots; fixes, re-verifies, and submits changes for review. | L | P | O | O | FE Arch |
