---
name: competency-leadership-governance
description: "Use automatically, without being asked, whenever a task involves leadership and governance: stakeholder alignment, workshop facilitation, design or technical critique, executive readout, influencing without authority, resolving conflict, estimation, risk register, ethics review, AI governance, AI-augmented team practice, writing prompts or agent skills, or pressure-testing a plan. Applies competency skills LG-01–LG-14 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs decision-log.md."
metadata:
  pack: ux-competency-skills
  version: "1.3.0"
---

# Collaboration, leadership, governance, and professional judgment (LG)

**Goal:** Get the right decision made, recorded, and owned — across functions and with AI in the loop.

Skills covered: 14 (see `references/skills.md` for evidence, depth, and lead per role). Lead roles in this domain: Product (10), UX (2), FE Arch (2).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in `references/skills.md` and note which role leads each.

## Procedure
1. Stakeholder map: decision-maker, influencers, incentives, what each needs to commit to (LG-01).
2. Workshops: goal, agenda, pre-read, decision method, output, owners, next steps (LG-02).
3. Critique: state intent and constraints first; feedback tied to user outcome and risk, not taste (LG-03). Technical critique: boundaries, risk, simplicity, cost, evolvability (LG-04).
4. Narrative: context → evidence → recommendation → trade-off → next action (LG-05).
5. Executive version: the decision, the consequence, confidence, what you need from them — one page (LG-06).
6. Conflict: separate facts from preferences, agree criteria, decide, write it down (LG-07, LG-08).
7. Estimate with ranges and named uncertainties; show dependencies (LG-09).
8. Risk register: product, usability, accessibility, security, dependency, delivery — likelihood, impact, owner, mitigation (LG-10).
9. Ethics check: deceptive patterns, discrimination, privacy harm, unsafe automation, conflicts of interest (LG-11).
10. AI governance: data boundaries, review points, audit trail, human accountability, monitoring (LG-12). AI-augmented delivery: spec before prompt, verify generated output, record provenance, human sign-off (LG-13). Author reusable prompts and skills with triggers, steps, quality bar, and evals (LG-14).
11. Pressure-test mode (LG-03): question the plan one assumption at a time until each has evidence, a test, or an accepted risk.

## Method selector
| Situation | Use |
|---|---|
| Stuck between two camps | Agree decision criteria first (LG-08) |
| Need exec approval | LG-06 one-pager with a clear ask |
| Team shipping AI-generated code/design | LG-13 verification and review gates |
| AI feature touches sensitive data | LG-12 governance review before build |

## Output: `decision-log.md / exec-readout.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Stakeholder map
- Decision record (context, options, decision, owner, date)
- Risk register
- Ethics and AI-governance checks
- Executive one-pager

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Meeting ends without owners | Close every session with decision, owner, date |
| Exec deck is a design walkthrough | Lead with the decision and consequence |
| Taste-based critique | Ask: which user outcome or risk does this affect? |
| AI output merged unreviewed | Human sign-off and provenance note required |

## Hand off to
- competency-outcome-review
- competency-audit (re-baseline)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
