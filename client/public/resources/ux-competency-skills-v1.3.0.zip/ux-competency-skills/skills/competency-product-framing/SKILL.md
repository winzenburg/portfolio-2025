---
name: competency-product-framing
description: "Use automatically, without being asked, whenever a task involves product framing: frame a problem, define outcomes, map assumptions, size an opportunity, write a value proposition, JTBD, prioritize a backlog, design an experiment, or explain a trade-off. Applies competency skills PB-01–PB-12 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs product-brief.md."
metadata:
  pack: ux-competency-skills
  version: "1.3.0"
---

# Product framing, business, and systems thinking (PB)

**Goal:** Turn an ambiguous request into a bounded, testable product bet before anyone designs or builds.

Skills covered: 12 (see `references/skills.md` for evidence, depth, and lead per role). Lead roles in this domain: Product (11), UX (1).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in `references/skills.md` and note which role leads each.

## Procedure
1. Restate the request as a problem statement: who is affected, what they are trying to do, what is going wrong, and what change would count as success (PB-01).
2. Write outcomes in three separate lines — customer, business, operational — and keep feature output out of them (PB-02).
3. List assumptions under four headings: value, usability, feasibility, viability. Mark each as known / believed / unknown and name the cheapest test for the riskiest unknowns (PB-03, PB-11).
4. Size the opportunity with whatever evidence exists (tickets, funnel loss, revenue at risk, interview frequency). State confidence, not false precision (PB-04).
5. Map the domain: entities, rules, vocabulary, exceptions, and the systems and people around the experience (PB-07, PB-08).
6. Translate strategy into 3–5 experience principles and explicit decision criteria (PB-09).
7. Sequence the work with a named method (RICE, cost of delay, risk-first) and show the scoring (PB-10).
8. Close with a trade-off table for the main choice: option, customer effect, business effect, technical cost, risk (PB-12).

## Method selector
| Situation | Use |
|---|---|
| Request is a solution in disguise ("add a dashboard") | Five whys to the underlying job, then PB-01 |
| Leadership disagrees on direction | Decision criteria first (PB-09), options second |
| High uncertainty, low cost to learn | Experiment design (PB-11) before any build |
| Complex regulated or operational domain | Domain model + systems map (PB-07, PB-08) before flows |

## Output: `product-brief.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Problem statement
- Outcomes (customer / business / operational)
- Assumption map + tests
- Opportunity size and confidence
- Domain and systems map
- Principles and decision criteria
- Prioritized bets
- Trade-offs

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Outcome is a feature ("launch X") | Rewrite as a change in behavior or result that X is meant to cause |
| Every assumption is marked 'known' | Ask for the evidence behind each; unsupported ones become 'believed' |
| Prioritization with no visible method | Show the scores and the inputs so others can challenge them |
| Trade-offs listed only in design terms | Add business, technical, legal, and operational columns |

## Hand off to
- competency-user-research (test value/usability assumptions)
- competency-measurement (turn outcomes into metrics)
- competency-ia-interaction (once the problem is bounded)

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
