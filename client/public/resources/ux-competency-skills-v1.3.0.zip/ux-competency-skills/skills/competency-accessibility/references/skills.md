# Accessibility, inclusion, and responsible experience design (AX) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| AX-01 | Accessibility requirements definition | Converts applicable standards, policy, and risk into testable experience requirements. | P | P | P | O | FE Arch |
| AX-02 | Inclusive research recruitment | Includes relevant disability, age, language, literacy, device, and context diversity in research. | P | O | L | L | UX |
| AX-03 | Keyboard interaction design | Defines logical focus order, visible and unobscured focus (WCAG 2.4.7, 2.4.11), shortcuts, no keyboard traps, escape behavior, and reachability. | P | O | P | O | UX |
| AX-04 | Screen-reader interaction design | Specifies meaningful names, roles, states, relationships, announcements, and reading order. | P | O | P | O | UX |
| AX-05 | Semantic HTML application | Chooses native semantic elements before implementing custom widgets or ARIA. | L | P | P | O | FE Arch |
| AX-06 | Color and non-color signaling | Ensures color is not the only carrier of state, priority, category, or error. | P | P | O | P | UI |
| AX-07 | Contrast verification | Tests text (WCAG 1.4.3), non-text controls and focus indicators (1.4.11), and every interactive state against the relevant thresholds. | P | P | O | P | UI |
| AX-08 | Accessible-form design | Provides persistent labels, instructions, error association, validation timing, input purpose, no redundant entry (WCAG 3.3.7), and accessible authentication (3.3.8). | P | O | P | O | UX |
| AX-09 | Accessible-media design | Provides captions, transcripts, audio description considerations, and controllable media behavior. | L | P | P | P | UX |
| AX-10 | Cognitive-accessibility design | Reduces unnecessary complexity, memory load, ambiguity, surprise, and time pressure. | P | O | P | P | UX |
| AX-11 | Touch and mobile accessibility | Accounts for target size (WCAG 2.5.8, 24×24 CSS px minimum), dragging alternatives (2.5.7), motion, orientation, zoom/reflow, device settings, and alternate inputs. | P | P | O | O | UI |
| AX-12 | Accessibility test and remediation | Combines automated checks, keyboard testing, assistive-technology checks, and human judgment into actionable fixes. | P | P | P | O | FE Arch |
