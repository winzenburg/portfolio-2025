# Front-end foundations and browser-platform fluency (FE) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| FE-01 | HTML document structure | Builds a correct document outline, landmarks, metadata, forms, and content hierarchy. | L | P | P | O | FE Arch |
| FE-02 | CSS cascade reasoning | Predicts inheritance, specificity, layers, scope, and resulting style behavior. | L | L | P | O | FE Arch |
| FE-03 | Modern layout implementation | Uses Grid, Flexbox, intrinsic sizing, container-aware behavior, and logical properties appropriately. | L | P | P | O | FE Arch |
| FE-04 | Responsive implementation | Implements fluid layouts, appropriate breakpoints, media features, and viewport behavior. | L | P | P | O | FE Arch |
| FE-05 | JavaScript and TypeScript fluency | Uses types, data transformation, async patterns, modules, and error handling safely. | L | L | L | O | FE Arch |
| FE-06 | DOM and event-model reasoning | Handles propagation, delegation, focus, input, pointer, keyboard, and lifecycle interactions correctly. | L | P | P | O | FE Arch |
| FE-07 | Browser API selection | Chooses browser capabilities such as storage, observers, workers, history, clipboard, and media APIs responsibly. | — | L | L | O | FE Arch |
| FE-08 | Semantic component implementation | Prefers native elements and exposes accessible semantics when custom behavior is necessary. | L | P | P | O | FE Arch |
| FE-09 | Client-side routing | Implements route structure, deep links, parameters, guards, navigation state, and recovery. | L | L | L | O | FE Arch |
| FE-10 | Framework lifecycle knowledge | Understands rendering, effects, hydration, reactivity, suspense, and cleanup in the chosen stack. | — | L | L | O | FE Arch |
| FE-11 | Package and dependency literacy | Evaluates package purpose, quality, license, maintenance, bundle cost, and security posture. | — | L | L | O | FE Arch |
| FE-12 | Build-tool fluency | Configures development, test, build, lint, formatting, environment, and deployment workflows. | — | L | L | O | FE Arch |
| FE-13 | Motion implementation | Implements animation with compositor-friendly properties, interruptible timing, scroll-driven techniques, and reduced-motion support inside performance budgets. | — | L | P | O | FE Arch |
| FE-14 | Immersive graphics | Uses Canvas, SVG, WebGL/3D, and physics libraries only when they serve the experience, with fallbacks, performance limits, and accessible alternatives. | — | L | P | O | FE Arch |
