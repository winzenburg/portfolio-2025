---
name: competency-ia-interaction
description: "Use automatically, without being asked, whenever a task involves IA and interaction design: design navigation, taxonomy, search and filters, user flows, task flows, forms, interaction states, error prevention, feedback/status, interaction patterns, or iOS/Android/web platform conventions. Applies competency skills IA-01–IA-13 with a step-by-step procedure, quality checks, and the lead role for each; for larger work, outputs flows.md."
metadata:
  pack: ux-competency-skills
  version: "1.3.0"
---

# Information architecture and interaction design (IA)

**Goal:** Make the workflow completable: clear structure, complete states, and recoverable errors.

Skills covered: 13 (see `references/skills.md` for evidence, depth, and lead per role). Lead roles in this domain: UX (13).

## Before you start
- Read `docs/competency/brief.md` and `audit.md` if they exist; otherwise ask for, or state, the product, users, and decision at stake in two or three lines.
- Look up the skill IDs you will use in `references/skills.md` and note which role leads each.

## Procedure
1. Inventory what exists: content, data objects, owners, duplication (IA-01).
2. Define categories and labels in the user's vocabulary; write inclusion rules for each (IA-02).
3. Draw the flow from entry to completion, including exceptions and follow-up. Mark each decision point and each place the user must remember something (IA-05, IA-06).
4. Cut steps: remove, merge, default, or defer anything that doesn't serve the goal (IA-06).
5. For every screen, fill the state matrix: default, loading, empty, partial, error, success, permission-denied, disabled, destructive-confirm (IA-07).
6. For forms: group fields, set validation timing, dependencies, defaults, input modes, and recovery (IA-08, AX-08).
7. Add error prevention: constraints, sensible defaults, progressive disclosure, confirmation for irreversible actions, undo where possible (IA-09).
8. Specify feedback for every action: what the user sees, when, and for how long (IA-10).
9. Choose patterns by intent, risk, frequency, and platform convention; justify any custom pattern (IA-11). On mobile, follow iOS/Android conventions for navigation, gestures, and system settings (IA-13).

## Method selector
| Situation | Use |
|---|---|
| Users can't find things | Card sort / tree test, then IA-02–IA-04 |
| Users start but don't finish | Task-flow optimization (IA-06) + funnel data (ME-05) |
| High-risk or irreversible actions | Error prevention (IA-09) + confirmation and undo |
| Large data sets | Findability design (IA-04): search, facets, sort, zero-result recovery |

## Output: `flows.md`
Use these headings. Tag each section with the skill IDs it evidences.

- Scope and entry points
- Information structure / taxonomy
- Flow diagrams (Mermaid acceptable)
- State matrix per screen
- Form rules
- Error prevention and recovery
- Pattern decisions

## Quality bar
- Every claim cites evidence or is labeled as an assumption.
- Every recommendation names a Lead role and the next decision.
- Accessibility (AX) and risk (LG-10) are considered, even if briefly.

## Failure modes
| Symptom | Fix |
|---|---|
| Only the happy path is designed | Complete the state matrix before visual design |
| Labels use internal jargon | Replace with terms heard in research (CX-03) |
| Confirmation dialogs on everything | Reserve for irreversible actions; prefer undo |
| Custom pattern where a standard one fits | Use the platform convention unless research says otherwise |

## Hand off to
- competency-ui-visual
- competency-content-service-ai (labels, errors, empty states)
- competency-prototyping-handoff

## Right-size the output
- **Small task** (one component, one fix, one page of copy): apply the relevant steps and checks directly in the work. Don't create files or narrate the skill.
- **Multi-step work** (a playbook, an audit, a redesign, or when the user asks for a plan): keep artifacts as described below.

## Workspace (multi-step work only)
If you can write files, keep artifacts in the project at `docs/competency/`:
`brief.md` · `audit.md` · `plan.md` · `chain-log.md` · `<domain>/…` · `outcome-review.md`.
Append one line to `chain-log.md` per skill run: date, skill, skill IDs used, artifact path, decision made.
If you cannot write files (chat-only, e.g. Grok web), return the same artifact inline as Markdown with the same headings.
