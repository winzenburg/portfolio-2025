# Information architecture and interaction design (IA) — skill reference

**Depth:** O = deep specialist (expected to set the standard) · P = independent practitioner · L = working literacy (can review and make trade-offs) · — = outside normal scope.
**Lead:** the one role that is accountable, breaks ties, and signs off. Several roles can be O; only one leads.
**Evidence scale for audits:** 0 unexposed · 1 assisted · 2 independent · 3 sets the standard · 4 evolves the discipline. Rough mapping: L ≈ 1–2, P ≈ 2–3, O ≈ 3–4.

| ID | Skill | Observable evidence | Product | UX | UI | FE Arch | Lead |
|---|---|---|---|---|---|---|---|
| IA-01 | Content inventory | Enumerates current content, data, formats, owners, status, and duplication. | P | O | P | P | UX |
| IA-02 | Taxonomy design | Creates clear categories, labels, relationships, and inclusion rules for information. | P | O | P | P | UX |
| IA-03 | Navigation design | Organizes global, local, contextual, and utility navigation around user goals. | P | O | P | P | UX |
| IA-04 | Findability design | Designs search, browse, filters, sort, facets, and zero-result recovery. | P | O | P | P | UX |
| IA-05 | User-flow design | Defines a coherent sequence from entry through completion, exception, and follow-up. | O | O | P | P | UX |
| IA-06 | Task-flow optimization | Removes avoidable steps, decisions, memory demands, and context switches. | O | O | P | P | UX |
| IA-07 | Interaction-state design | Specifies default, loading, empty, error, success, permission, disabled, and destructive states. | O | O | O | O | UX |
| IA-08 | Form design | Designs field grouping, validation, dependencies, defaults, input modes, and recovery. | P | O | P | O | UX |
| IA-09 | Error-prevention design | Uses constraints, progressive disclosure, sensible defaults, confirmation, and undo. | P | O | P | O | UX |
| IA-10 | Feedback and status design | Makes system status, latency, progress, and outcome legible at the point of need. | P | O | O | O | UX |
| IA-11 | Interaction-pattern selection | Selects patterns that match user intent, risk, frequency, device, and platform conventions. | O | O | O | P | UX |
| IA-12 | Service-blueprint translation | Translates an existing service blueprint into screen-level states, handoffs, and failure handling the product must support. | P | P | L | P | UX |
| IA-13 | Platform-convention fluency | Applies iOS, Android, and web conventions for navigation, gestures, controls, and system settings; deviates only with a stated reason. | P | O | O | P | UX |
