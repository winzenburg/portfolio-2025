# Changelog

## 1.3.0 — 2026-09-15
- Skills now load automatically: every description starts with "Use automatically, without being asked, whenever…" and names its triggers.
- Added `cursor/user-rule.txt`, an always-on Cursor User Rule that routes tasks to skills, and `./install.sh cursor-global`.
- Added right-sizing: small tasks apply the checks inline with no files; `docs/competency/` is used only for multi-step work. The router hands single-domain requests straight to the right skill and doesn't ask which skill to use.

## 1.2.0 — 2026-09-15
Crosswalk against the Aura skills library (aura.build/skills, 167 unique skills). See AURA-CROSSWALK.md.
- New domain 14 **Growth, conversion, and marketing surfaces** (GM-01–GM-10) and skill `competency-growth-conversion`.
- New skills: IA-13, UI-13, UI-14, DS-13, PR-13, FE-13, FE-14, LG-14.
- Refined: UI-12, ME-02, QL-07, LG-03.
- Added **Conflict rules** to TAXONOMY.md and wired them into the UI, DS, PR, FE, GM, and LG skills.
- New playbooks: Marketing site / conversion, UI polish pass, Pressure test.

### Row changes
- ADDED IA-13 Platform-convention fluency — Aura crosswalk: mobile-design-thinking, apple-design
- ADDED UI-13 Visual direction — Aura crosswalk: taste-skill, impeccable-designer, creative-agency-design-protocol, frontend-design, design-dna, image art-direction skills
- ADDED UI-14 Interface polish — Aura crosswalk: details-that-make-interfaces-feel-better, visual-polish-specialist, design-engineering, baseline-ui, typography-cleanup-specialist, beautiful-shadows
- ADDED DS-13 Design-system extraction — Aura crosswalk: extract-design-system, design-dna, ui-consistency-auditor
- ADDED PR-13 Rendered-UI verification — Aura crosswalk: web-design-reviewer, improve-ui, ui-audit-and-quality-review, web-interface-guidelines
- ADDED FE-13 Motion implementation — Aura crosswalk: GSAP, anime.js, animation-systems, ui-animation-guidelines, gsap-performance
- ADDED FE-14 Immersive graphics — Aura crosswalk: three.js, WebGL, cobe, vanta, matter.js, Unicorn Studio skills
- ADDED LG-14 Prompt and skill authoring — Aura crosswalk: skill-creator, prompt-engineer, advanced-ui-prompt-architect, find-skills
- ADDED GM-01 Landing-page architecture — Aura crosswalk: landing-page-high-conversion, saas/editorial page systems
- ADDED GM-02 Conversion copywriting — Aura crosswalk: copywriting
- ADDED GM-03 Pricing-page design — Aura crosswalk: high-conversion-saas-pricing-page-design
- ADDED GM-04 Upgrade and paywall design — Aura crosswalk: paywall-and-upgrade-screen-cro
- ADDED GM-05 Proof design — Aura crosswalk: product-proof-saas, operational-enterprise-ai, company-logos
- ADDED GM-06 Ethical persuasion design — Aura crosswalk: marketing-psychology-mental-models (bounded by LG-11)
- ADDED GM-07 Conversion experiment program — Aura crosswalk: CRO skills
- ADDED GM-08 Search and AI-answer discoverability — Aura crosswalk: geo-generative-engine-optimization-strategies, image-optimization-analysis, features-page-generator
- ADDED GM-09 Brand strategy translation — Aura crosswalk: branding-strategies
- ADDED GM-10 Launch and early-traction design — Aura crosswalk: cold-start-strategies
- UI-12 Motion and transition design: evidence rewritten — Aura crosswalk: added 'where motion earns its place' and springs/interruption (finding-animation-opportunities, apple-design)
- ME-02 Measurement-plan design: evidence rewritten — Aura crosswalk: analytics-tracking adds campaign attribution
- QL-07 Performance-budget management: evidence rewritten — Aura crosswalk: image-optimization and gsap-performance
- LG-03 Design critique: evidence rewritten — Aura crosswalk: grill-me folded in as a critique mode

## 1.1.0 — {DATE}
Refinement of the 2026-09-10 taxonomy and repackaging as an open-standard `SKILL.md` pack for Cursor and Grok.

### Structural fixes
- **Added a Lead column.** In the original, 66 of 156 rows had zero or several "O" owners (IA-07, UI-10, PR-07, PR-12, LG-05 and LG-11 had four). "O" was doing two jobs: *deep specialist* and *accountable owner*. O now means depth only; every skill names exactly one Lead.
- **Depth legend mapped to the 0–4 evidence scale** so audits and role ratings use one language.
- **Senior role summary aligned with the rows.** Accessibility now shows UX as design lead (AX-03/04/08 are UX-led) alongside FE as implementation lead; IA/flows and visual design now show Product as co-owner rather than a second lead, matching the row-level leads.
- **Domain order in the pack follows the delivery sequence** (framing → research → IA → content/AI → UI → accessibility → systems → spec → build → quality → measurement → leadership). Skill IDs are unchanged.

### Row changes
- CX-06 Notification design: UX P → O
- CX-06 Notification design: FE O → P
- RE-02 Stakeholder interview design: UX P → O
- QL-12 Incident participation: evidence rewritten — grammar (verb agreement) and explicit post-incident learning
- QL-06 Performance measurement: evidence rewritten — named the current Core Web Vitals so the skill is testable
- AX-03 Keyboard interaction design: evidence rewritten — anchored to WCAG 2.2 success criteria
- AX-07 Contrast verification: evidence rewritten — anchored to WCAG success criteria
- AX-08 Accessible-form design: evidence rewritten — added WCAG 2.2 form criteria
- AX-11 Touch and mobile accessibility: evidence rewritten — added WCAG 2.2 pointer criteria
- IA-12 Service-blueprint translation: evidence rewritten — disambiguated from CX-11 (IA-12 consumes a blueprint; CX-11 creates one)
- CX-11 Service-design orchestration: evidence rewritten — disambiguated from IA-12
- CX-06 Notification design: evidence rewritten — ownership moved to UX; FE owns delivery infrastructure via AR/QL skills
- LG-11 Ethical decision-making: evidence rewritten — named deceptive patterns explicitly and added escalation
- ADDED CX-13 AI evaluation design — the original priority sequence names 'evaluation' but no skill measured it
- ADDED LG-13 AI-augmented delivery practice — AI agents are now part of the delivery system; the skill is the operating discipline, not the tool

### References added
- web.dev Core Web Vitals (supports QL-06/QL-07) and the WAI ARIA Authoring Practices Guide (supports FE-08/AX-05).

## 1.0.0 — 2026-09-10
Original taxonomy: 156 skills, 13 domains.
